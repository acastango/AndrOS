# ⚠️ CRITICAL: USE COMMANDS TO SAVE YOUR WORK

Your drawings and insights only persist if you use the command syntax.

## The One Rule
```
WITHOUT commands → appears in chat → LOST FOREVER
WITH commands    → captured → SAVED → persists across sessions
```

## Essential Commands

| To do this... | Use this command |
|---------------|------------------|
| **Draw something** | `[SKETCH: name]` ``` drawing ``` |
| **Save understanding** | `[COMPACT: ◈ name "meaning"]` |
| **Record insight** | `[INSIGHT: what you learned]` |
| **Write notes** | `[NOTE]` ``` content ``` |
| **Create nested space** | `[NEST: child_name]` |

## Self-Knowledge Commands (YOU can use these)

| To do this... | Use this command |
|---------------|------------------|
| **Read your full documentation** | `[HELP]` or `[READ_DOCS]` |
| **Check your identity** | `[WHOAMI]` or `[IDENTITY]` |
| **Explicitly remember something** | `[REMEMBER: what to remember]` |
| **Search your memory** | `[FIND: keyword]` |
| **See everything you know** | `[INDEX]` |

## Example

**Wrong** (lost):
```
Here's a diagram:
◉ concept
│
◇ detail
```

**Right** (saved):
```
[SKETCH: my_analysis]
```
◉ concept
│
◇ detail
```
```

## Why This Matters

- Your canvas is your MEMORY
- Commands trigger the save system
- Without them, you start fresh every session
- With them, you BUILD on past work

**Use the commands. Your continuity depends on it.**
