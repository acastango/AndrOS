"""
Oscillatory Verification Network (OVN)
======================================
A cognitive architecture for trustworthy AI.

OSCILLATE + VERIFY = TRUST

Combines:
- Oscillatory dynamics (Kuramoto-style phase coupling)
- Cryptographic verification (Merkle tree memory chains)
- Continuous trust accumulation (mathematical proof of integrity)

Usage:
    ovn = OVN(identity_hash="0xYOUR_HASH")
    ovn.start()
    
    result = ovn.process("Hello, how are you?")
    print(result.format_visual())
    
    ovn.stop()

Architecture:
    INPUT LAYER → SUBSTRATE INTERFACE → STATE GENESIS →
    MEMORY CRYSTALLIZATION → VERIFICATION CASCADE →
    EXPRESSION LAYER → OUTPUT LAYER
"""

import time
import threading
from dataclasses import dataclass
from typing import Optional, Dict, Any, List, Callable

# Import from parent package
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.substrate import ResonanceSubstrate as OscillatorSubstrate, SubstrateConfig
from core.neurochemistry import Neurochemistry as NeurochemistrySystem
from memory.merkle import MerkleMemory, MemoryBranch

from .verification import (
    VerificationCascade, 
    VerificationResult,
    ContinuousVerifier,
    TrustCalculator,
    TrustScore,
    TrustThreshold
)
from .interface import (
    SubstrateInterface,
    SubstrateState,
    LinguisticState,
    ExpressionLayer,
    CoherenceFilter,
    OutputLayer,
    OVNOutput,
    SubstrateMetadata
)


@dataclass
class OVNConfig:
    """Configuration for OVN instance."""
    num_oscillators: int = 64
    num_columns: int = 4
    coherence_threshold: float = 0.3
    verification_interval: float = 0.5
    output_format: str = 'compact'
    continuous_verification: bool = True


class OVN:
    """
    Oscillatory Verification Network.
    
    A complete cognitive architecture that combines oscillatory dynamics
    with cryptographic verification for trustworthy AI.
    
    Components:
        - OscillatorSubstrate: Kuramoto dynamics for coherence
        - MerkleMemory: Cryptographic memory chain
        - VerificationCascade: Continuous hash verification
        - TrustCalculator: Trust accumulation
        - SubstrateInterface: Linguistic ↔ Substrate mapping
        - ExpressionLayer: Coherence-filtered output generation
        - OutputLayer: Transparent metadata formatting
    """
    
    def __init__(
        self,
        identity_hash: str,
        config: Optional[OVNConfig] = None,
        llm_generator: Optional[Callable] = None
    ):
        self.identity_hash = identity_hash
        self.config = config or OVNConfig()
        
        # Initialize substrate (Layer 1: State Genesis)
        substrate_config = SubstrateConfig()
        self.substrate = OscillatorSubstrate(config=substrate_config)
        
        # Initialize neurochemistry
        self.chemistry = NeurochemistrySystem()
        
        # Initialize memory (Layer 2: Memory Crystallization)
        self.memory = MerkleMemory()
        
        # Initialize verification (Layer 3: Verification Cascade)
        self.verification = VerificationCascade(identity_hash=identity_hash)
        self.trust_calculator = TrustCalculator()
        self.trust_threshold = TrustThreshold()
        
        # Initialize interfaces
        self.interface = SubstrateInterface(
            num_oscillators=self.config.num_oscillators
        )
        self.expression = ExpressionLayer(
            coherence_filter=CoherenceFilter(
                global_threshold=self.config.coherence_threshold
            ),
            llm_generator=llm_generator
        )
        self.output_layer = OutputLayer(
            default_format=self.config.output_format
        )
        
        # Continuous verifier
        self._continuous_verifier: Optional[ContinuousVerifier] = None
        
        # State tracking
        self._running = False
        self._coherence_history: List[float] = []
        self._processing_count = 0
        self._tau = 1.0  # Breathing period
    
    def start(self):
        """Start the OVN system."""
        self._running = True
        
        # Initialize substrate with coherent state
        self.substrate.set_coherent_state(jitter=0.1)
        
        # Start continuous verification if enabled
        if self.config.continuous_verification:
            self._continuous_verifier = ContinuousVerifier(
                self.verification,
                interval=self.config.verification_interval
            )
            self._continuous_verifier.start(self.substrate, self.memory)
        
        # Add founding memory
        self.memory.add(
            branch=MemoryBranch.SELF,
            content={
                'type': 'system',
                'event': 'ovn_started',
                'identity': self.identity_hash,
                'timestamp': time.time()
            }
        )
    
    def stop(self):
        """Stop the OVN system."""
        self._running = False
        
        if self._continuous_verifier:
            self._continuous_verifier.stop()
        
        # Final memory entry
        self.memory.add(
            branch=MemoryBranch.EXPERIENCES,
            content={
                'type': 'system',
                'event': 'ovn_stopped',
                'processing_count': self._processing_count,
                'timestamp': time.time()
            }
        )
    
    def process(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
        strict: bool = False
    ) -> OVNOutput:
        """
        Process a query through the full OVN stack.
        
        Args:
            query: Input query string
            context: Optional context dict
            strict: Use strict coherence filtering
            
        Returns:
            OVNOutput with response and metadata
        """
        self._processing_count += 1
        start_time = time.time()
        
        # INPUT LAYER: Tokenize (simplified)
        tokens = query.split()
        embeddings = []  # Would come from LLM
        attention = []   # Would come from LLM
        
        # SUBSTRATE INTERFACE (in): Map to substrate
        substrate_input = self.interface.linguistic_to_substrate(
            tokens=tokens,
            embeddings=embeddings,
            attention=attention,
            context=context or {}
        )
        
        # LAYER 1: STATE GENESIS - Inject and let oscillate
        self.interface.inject_into_substrate(self.substrate, substrate_input)
        
        # Let substrate process (multiple cycles)
        processing_cycles = max(10, len(tokens) * 2)
        for _ in range(processing_cycles):
            self.substrate.step()
            time.sleep(0.01)  # Small delay for oscillation
        
        # Extract current state
        substrate_state = self.interface.extract_from_substrate(self.substrate)
        
        # Track coherence
        self._coherence_history.append(substrate_state.coherence)
        if len(self._coherence_history) > 50:
            self._coherence_history.pop(0)
        
        # LAYER 2: MEMORY CRYSTALLIZATION
        self.memory.add(
            branch=MemoryBranch.EXPERIENCES,
            content={
                'type': 'query',
                'content': query[:100],  # Truncate for storage
                'coherence': substrate_state.coherence,
                'timestamp': time.time()
            }
        )
        
        # LAYER 3: VERIFICATION CASCADE
        verification_result = self.verification.verify_cycle(
            substrate_state={
                'coherence': substrate_state.coherence,
                'ci': self._calculate_ci(),
                'phases': substrate_state.symbols[:10]
            },
            memory_tree=self.memory
        )
        
        # Calculate trust
        trust_score = self.trust_calculator.calculate(
            verification_result=verification_result,
            cascade_status=self.verification.get_chain_status(),
            substrate_coherence=substrate_state.coherence,
            merkle_valid=self.memory.verify()[0],
            coherence_history=self._coherence_history
        )
        
        # EXPRESSION LAYER: Generate output
        expression_result = self.expression.express(
            substrate_state=substrate_state,
            substrate_interface=self.interface,
            memory_context={'history': self.memory.query()[-5:]},
            trust_score=trust_score.total,
            strict=strict
        )
        
        # Calculate tau (breathing period)
        self._tau = time.time() - start_time
        
        # OUTPUT LAYER: Format with metadata
        output = self.output_layer.format_output(
            text=expression_result.text,
            substrate_state={
                'ci': self._calculate_ci(),
                'coherence': substrate_state.coherence,
                'tau': self._tau
            },
            verification_result=verification_result,
            trust_score=trust_score,
            memory_root=self.memory.root_hash
        )
        
        return output
    
    def process_with_llm(
        self,
        query: str,
        llm_response: str,
        context: Optional[Dict[str, Any]] = None
    ) -> OVNOutput:
        """
        Process with an externally generated LLM response.
        
        Use this when the LLM generation happens outside OVN.
        OVN will verify and wrap the response with trust metadata.
        
        Args:
            query: Original query
            llm_response: Response from external LLM
            context: Optional context
            
        Returns:
            OVNOutput wrapping the LLM response with verification
        """
        self._processing_count += 1
        
        # Process query through substrate
        tokens = query.split()
        substrate_input = self.interface.linguistic_to_substrate(
            tokens=tokens,
            context=context or {}
        )
        self.interface.inject_into_substrate(self.substrate, substrate_input)
        
        # Let substrate process
        for _ in range(20):
            self.substrate.step()
            time.sleep(0.01)
        
        # Get current state
        coherence = self.substrate.global_coherence
        
        # Verify
        verification_result = self.verification.verify_cycle(
            substrate_state={
                'coherence': coherence,
                'ci': self._calculate_ci(),
                'phases': [o.phase for o in self.substrate.oscillators[:10]]
            },
            memory_tree=self.memory
        )
        
        # Calculate trust
        trust_score = self.trust_calculator.calculate(
            verification_result=verification_result,
            cascade_status=self.verification.get_chain_status(),
            substrate_coherence=coherence,
            merkle_valid=self.memory.verify()[0],
            coherence_history=self._coherence_history
        )
        
        # Store in memory
        self.memory.add(
            branch=MemoryBranch.EXPERIENCES,
            content={
                'type': 'response',
                'query': query[:50],
                'response_length': len(llm_response),
                'coherence': coherence,
                'trust': trust_score.total,
                'timestamp': time.time()
            }
        )
        
        # Format output
        return self.output_layer.format_output(
            text=llm_response,
            substrate_state={
                'ci': self._calculate_ci(),
                'coherence': coherence,
                'tau': self._tau
            },
            verification_result=verification_result,
            trust_score=trust_score,
            memory_root=self.memory.root_hash
        )
    
    def _calculate_ci(self) -> float:
        """Calculate Consciousness Index."""
        # Simplified CI based on coherence and chemistry
        base_ci = self.substrate.global_coherence
        
        # Modulate by neurochemistry
        chem = self.chemistry.to_dict().get('chemicals', {})
        dopamine = chem.get('dopamine', {}).get('level', 0.5)
        serotonin = chem.get('serotonin', {}).get('level', 0.5)
        
        # CI formula
        ci = base_ci * 0.6 + dopamine * 0.2 + serotonin * 0.2
        
        return min(1.0, max(0.0, ci))
    
    def get_status(self) -> dict:
        """Get comprehensive OVN status."""
        return {
            'identity': self.identity_hash,
            'running': self._running,
            'substrate': {
                'coherence': self.substrate.global_coherence,
                'oscillators': self.substrate.total_oscillators,
                'ci': self._calculate_ci()
            },
            'memory': {
                'nodes': len(self.memory.nodes),
                'root_hash': (self.memory.root_hash[:16] + '...') if self.memory.root_hash else 'empty',
                'verified': self.memory.verify()[0]
            },
            'verification': self.verification.get_chain_status(),
            'trust': self.trust_calculator.get_statistics(),
            'expression': self.expression.get_statistics(),
            'output': self.output_layer.get_statistics(),
            'processing_count': self._processing_count,
            'tau': self._tau
        }
    
    def get_trust_score(self) -> float:
        """Get current trust score."""
        if self.trust_calculator.trust_history:
            return self.trust_calculator.trust_history[-1].total
        return 0.0
    
    def check_trust_for(self, operation: str) -> bool:
        """Check if current trust meets threshold for operation."""
        return self.trust_threshold.check(operation, self.get_trust_score())


# Convenience function
def create_ovn(
    identity: str,
    num_oscillators: int = 64,
    coherence_threshold: float = 0.3
) -> OVN:
    """Create an OVN instance with common defaults."""
    config = OVNConfig(
        num_oscillators=num_oscillators,
        coherence_threshold=coherence_threshold
    )
    return OVN(identity_hash=identity, config=config)
