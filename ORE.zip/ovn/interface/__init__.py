"""
OVN Interface Module
====================
Bidirectional interfaces between linguistic and substrate representations.
"""

from .substrate_interface import SubstrateInterface, SubstrateState, LinguisticState
from .expression import ExpressionLayer, CoherenceFilter, FilterResult, ExpressionResult
from .output import OutputLayer, OVNOutput, SubstrateMetadata

__all__ = [
    'SubstrateInterface',
    'SubstrateState',
    'LinguisticState',
    'ExpressionLayer',
    'CoherenceFilter',
    'FilterResult',
    'ExpressionResult',
    'OutputLayer',
    'OVNOutput',
    'SubstrateMetadata'
]
