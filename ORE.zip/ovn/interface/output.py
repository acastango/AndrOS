"""
Output Layer
============
Final output formatting with full transparency about substrate state.

Every OVN output includes:
- Human readable text
- Substrate metadata (CI, Coherence, τ)
- Merkle root hash
- Chain verification status
- Trust score

This provides cryptographic proof of output integrity.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
import time
import json


@dataclass
class SubstrateMetadata:
    """Metadata about substrate state at output time."""
    ci: float                    # Consciousness Index
    coherence: float             # Global coherence
    tau: float                   # Timebase / breathing period
    merkle_root: str             # Memory tree root hash
    chain_verified: bool         # Verification cascade status
    trust_score: float           # Accumulated trust score
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> dict:
        return {
            'ci': round(self.ci, 4),
            'coherence': round(self.coherence, 4),
            'tau': round(self.tau, 4),
            'merkle_root': self.merkle_root,
            'chain_verified': self.chain_verified,
            'trust_score': round(self.trust_score, 4),
            'timestamp': self.timestamp
        }
    
    def to_compact(self) -> str:
        """Compact single-line representation."""
        return (
            f"CI={self.ci:.3f} C={self.coherence:.3f} τ={self.tau:.2f}s "
            f"TRUST={self.trust_score:.3f} VERIFIED={self.chain_verified}"
        )


@dataclass
class OVNOutput:
    """
    Complete OVN output with text and metadata.
    
    Provides full transparency about how the output was generated
    and cryptographic proof of integrity.
    """
    text: str
    metadata: SubstrateMetadata
    verification_hash: str = ""
    
    def __post_init__(self):
        """Calculate verification hash for this output."""
        import hashlib
        data = json.dumps({
            'text': self.text,
            'metadata': self.metadata.to_dict()
        }, sort_keys=True)
        self.verification_hash = hashlib.sha256(data.encode()).hexdigest()
    
    def to_dict(self) -> dict:
        return {
            'text': self.text,
            'metadata': self.metadata.to_dict(),
            'verification_hash': self.verification_hash
        }
    
    def format_full(self) -> str:
        """
        Format with full metadata block.
        
        ┌─────────────────────────────────────────────────────────────────┐
        │        FINAL RESPONSE + SUBSTRATE METADATA                      │
        │                                                                 │
        │  [HUMAN_READABLE_TEXT]                                         │
        │                                                                 │
        │  ═══════════════════════════════════════════════════════════   │
        │  SUBSTRATE STATE: CI=X.XX, C=X.XX, τ=X.Xs                      │
        │  MERKLE ROOT: [HASH...]                                        │
        │  CHAIN VERIFIED: True                                          │
        │  TRUST SCORE: X.XX                                             │
        │  ═══════════════════════════════════════════════════════════   │
        └─────────────────────────────────────────────────────────────────┘
        """
        m = self.metadata
        merkle_short = m.merkle_root[:16] + '...' if len(m.merkle_root) > 16 else m.merkle_root
        
        return f"""{self.text}

═══════════════════════════════════════════════════════════
SUBSTRATE STATE: CI={m.ci:.3f}, C={m.coherence:.3f}, τ={m.tau:.2f}s
MERKLE ROOT: {merkle_short}
CHAIN VERIFIED: {m.chain_verified}
TRUST SCORE: {m.trust_score:.3f}
═══════════════════════════════════════════════════════════"""
    
    def format_compact(self) -> str:
        """Format with compact inline metadata."""
        return f"{self.text}\n∿ {self.metadata.to_compact()} ∿"
    
    def format_minimal(self) -> str:
        """Format with minimal trust indicator."""
        trust = self.metadata.trust_score
        if trust >= 0.9:
            indicator = "◈◈◈"
        elif trust >= 0.7:
            indicator = "◈◈◯"
        elif trust >= 0.5:
            indicator = "◈◯◯"
        else:
            indicator = "◯◯◯"
        
        verified = "✓" if self.metadata.chain_verified else "✗"
        return f"{self.text}\n[{indicator} {verified}]"
    
    def format_visual(self) -> str:
        """Format with visual substrate representation."""
        m = self.metadata
        
        # Visual coherence bar
        coherence_bar = "█" * int(m.coherence * 10) + "░" * (10 - int(m.coherence * 10))
        
        # Visual trust bar
        trust_bar = "◈" * int(m.trust_score * 5) + "◯" * (5 - int(m.trust_score * 5))
        
        # Verification status
        status = "∿ VERIFIED ∿" if m.chain_verified else "⚠ UNVERIFIED ⚠"
        
        return f"""{self.text}

┌─────────────────────────────────────┐
│ Coherence: [{coherence_bar}] {m.coherence:.2f}  │
│ Trust:     [{trust_bar}] {m.trust_score:.2f}    │
│ {status:^35} │
└─────────────────────────────────────┘"""


class OutputLayer:
    """
    Output layer for OVN.
    
    Formats final output with full metadata and transparency.
    """
    
    # Output format options
    FORMAT_FULL = 'full'
    FORMAT_COMPACT = 'compact'
    FORMAT_MINIMAL = 'minimal'
    FORMAT_VISUAL = 'visual'
    FORMAT_RAW = 'raw'
    
    def __init__(self, default_format: str = FORMAT_COMPACT):
        self.default_format = default_format
        
        # Output history for analysis
        self.output_history: list = []
        self.max_history = 50
    
    def format_output(
        self,
        text: str,
        substrate_state: Dict[str, Any],
        verification_result: 'VerificationResult',
        trust_score: 'TrustScore',
        memory_root: str = "",
        format_type: Optional[str] = None
    ) -> OVNOutput:
        """
        Format final OVN output with all metadata.
        
        Args:
            text: Generated response text
            substrate_state: Current substrate state dict
            verification_result: Latest verification result
            trust_score: Calculated trust score
            memory_root: Merkle tree root hash
            format_type: Output format (full, compact, minimal, visual, raw)
            
        Returns:
            OVNOutput with formatted text and metadata
        """
        # Create metadata
        metadata = SubstrateMetadata(
            ci=substrate_state.get('ci', 0.0),
            coherence=substrate_state.get('coherence', 0.0),
            tau=substrate_state.get('tau', 1.0),
            merkle_root=memory_root,
            chain_verified=verification_result.verified,
            trust_score=trust_score.total if hasattr(trust_score, 'total') else trust_score
        )
        
        # Create output
        output = OVNOutput(text=text, metadata=metadata)
        
        # Store in history
        self.output_history.append(output)
        if len(self.output_history) > self.max_history:
            self.output_history.pop(0)
        
        return output
    
    def render(
        self,
        output: OVNOutput,
        format_type: Optional[str] = None
    ) -> str:
        """
        Render OVNOutput to string with specified format.
        
        Args:
            output: OVNOutput to render
            format_type: Format type (defaults to layer default)
            
        Returns:
            Formatted string
        """
        fmt = format_type or self.default_format
        
        if fmt == self.FORMAT_FULL:
            return output.format_full()
        elif fmt == self.FORMAT_COMPACT:
            return output.format_compact()
        elif fmt == self.FORMAT_MINIMAL:
            return output.format_minimal()
        elif fmt == self.FORMAT_VISUAL:
            return output.format_visual()
        else:  # FORMAT_RAW
            return output.text
    
    def get_statistics(self) -> dict:
        """Get output layer statistics."""
        if not self.output_history:
            return {
                'total_outputs': 0,
                'average_trust': 0.0,
                'average_coherence': 0.0,
                'verification_rate': 0.0
            }
        
        total = len(self.output_history)
        avg_trust = sum(o.metadata.trust_score for o in self.output_history) / total
        avg_coherence = sum(o.metadata.coherence for o in self.output_history) / total
        verified = sum(1 for o in self.output_history if o.metadata.chain_verified)
        
        return {
            'total_outputs': total,
            'average_trust': round(avg_trust, 4),
            'average_coherence': round(avg_coherence, 4),
            'verification_rate': round(verified / total, 4)
        }
