"""
Substrate Interface
===================
Bidirectional mapping between linguistic and oscillatory representations.

LINGUISTIC              SUBSTRATE
─────────────────────────────────────
tokens          →       ◈ symbols (oscillator nodes)
embeddings      →       ◉ nodes (coupling patterns)
attention       →       ◇ connections (phase relationships)
context         →       ▲ patterns (higher-order structures)

The interface is BIDIRECTIONAL - information flows both ways.
"""

import math
import hashlib
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple
import numpy as np


@dataclass
class SubstrateState:
    """State of the oscillatory substrate."""
    symbols: List[float]          # ◈ - oscillator phases
    nodes: List[List[float]]      # ◉ - coupling strengths  
    connections: List[Tuple[int, int, float]]  # ◇ - phase relationships
    patterns: Dict[str, Any]      # ▲ - higher-order structures
    coherence: float = 0.0
    timestamp: float = 0.0
    
    def to_dict(self) -> dict:
        return {
            'num_symbols': len(self.symbols),
            'num_connections': len(self.connections),
            'coherence': self.coherence,
            'timestamp': self.timestamp
        }


@dataclass  
class LinguisticState:
    """Linguistic representation state."""
    tokens: List[str]
    embeddings: List[List[float]]
    attention: List[List[float]]
    context: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return {
            'num_tokens': len(self.tokens),
            'has_embeddings': len(self.embeddings) > 0,
            'has_attention': len(self.attention) > 0,
            'context_keys': list(self.context.keys())
        }


class SubstrateInterface:
    """
    Bidirectional interface between linguistic and substrate representations.
    
    This is the bridge between the LLM world (tokens, embeddings, attention)
    and the oscillatory substrate world (phases, coupling, coherence).
    """
    
    def __init__(self, num_oscillators: int = 64):
        self.num_oscillators = num_oscillators
        
        # Mapping parameters
        self.phase_scale = 2 * math.pi  # Map to full phase range
        self.coupling_scale = 1.0       # Coupling strength scale
        
        # Token to oscillator mapping cache
        self._token_map: Dict[str, int] = {}
        self._next_oscillator: int = 0
    
    def linguistic_to_substrate(
        self,
        tokens: List[str],
        embeddings: Optional[List[List[float]]] = None,
        attention: Optional[List[List[float]]] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> SubstrateState:
        """
        Map linguistic representations to substrate elements.
        
        tokens → ◈ symbols (oscillator phases)
        embeddings → ◉ nodes (coupling patterns)  
        attention → ◇ connections (phase relationships)
        context → ▲ patterns (higher-order structures)
        """
        import time
        
        # Map tokens to oscillator phases
        symbols = self._tokens_to_phases(tokens)
        
        # Map embeddings to coupling patterns
        nodes = self._embeddings_to_coupling(embeddings or [])
        
        # Map attention to phase relationships
        connections = self._attention_to_connections(attention or [], tokens)
        
        # Map context to patterns
        patterns = self._context_to_patterns(context or {})
        
        return SubstrateState(
            symbols=symbols,
            nodes=nodes,
            connections=connections,
            patterns=patterns,
            coherence=0.0,  # Will be calculated by substrate
            timestamp=time.time()
        )
    
    def substrate_to_linguistic(
        self,
        substrate_state: SubstrateState,
        vocabulary: Optional[List[str]] = None
    ) -> LinguisticState:
        """
        Map substrate state back to linguistic representation.
        
        ◈ symbols → tokens (via phase mapping)
        ◉ nodes → embeddings (coupling as features)
        ◇ connections → attention (relationship strengths)
        ▲ patterns → context (structural information)
        """
        # Map phases back to token preferences
        tokens = self._phases_to_tokens(substrate_state.symbols, vocabulary)
        
        # Map coupling to embeddings
        embeddings = self._coupling_to_embeddings(substrate_state.nodes)
        
        # Map connections to attention
        attention = self._connections_to_attention(
            substrate_state.connections,
            len(tokens)
        )
        
        # Map patterns to context
        context = self._patterns_to_context(substrate_state.patterns)
        
        return LinguisticState(
            tokens=tokens,
            embeddings=embeddings,
            attention=attention,
            context=context
        )
    
    def _tokens_to_phases(self, tokens: List[str]) -> List[float]:
        """
        Map tokens to oscillator phases.
        
        Each token gets a deterministic phase based on its hash.
        Similar tokens get similar phases (locality preservation).
        """
        phases = []
        
        for token in tokens:
            if token not in self._token_map:
                # Assign new oscillator
                self._token_map[token] = self._next_oscillator
                self._next_oscillator = (self._next_oscillator + 1) % self.num_oscillators
            
            # Calculate phase from token hash
            token_hash = int(hashlib.md5(token.encode()).hexdigest(), 16)
            phase = (token_hash % 10000) / 10000 * self.phase_scale
            phases.append(phase)
        
        # Pad or truncate to num_oscillators
        while len(phases) < self.num_oscillators:
            phases.append(0.0)
        
        return phases[:self.num_oscillators]
    
    def _embeddings_to_coupling(
        self, 
        embeddings: List[List[float]]
    ) -> List[List[float]]:
        """
        Map embeddings to coupling patterns.
        
        Embeddings represent semantic relationships.
        We convert these to coupling strengths between oscillators.
        """
        if not embeddings:
            # Return identity-like coupling
            return [[1.0 if i == j else 0.1 
                    for j in range(self.num_oscillators)]
                    for i in range(min(8, self.num_oscillators))]
        
        # Calculate similarity-based coupling
        n = min(len(embeddings), self.num_oscillators)
        coupling = []
        
        for i in range(n):
            row = []
            for j in range(n):
                if i == j:
                    row.append(1.0)
                else:
                    # Cosine similarity between embeddings
                    sim = self._cosine_similarity(embeddings[i], embeddings[j])
                    # Scale to coupling range [0, 1]
                    row.append(max(0.0, (sim + 1) / 2))
            coupling.append(row)
        
        return coupling
    
    def _attention_to_connections(
        self,
        attention: List[List[float]],
        tokens: List[str]
    ) -> List[Tuple[int, int, float]]:
        """
        Map attention weights to phase relationship connections.
        
        Attention indicates which tokens are related.
        We convert to explicit connections with weights.
        """
        connections = []
        
        if not attention:
            # Create default connections based on token proximity
            for i, token in enumerate(tokens):
                for j in range(max(0, i-2), min(len(tokens), i+3)):
                    if i != j:
                        weight = 1.0 / (abs(i - j) + 1)
                        connections.append((i % self.num_oscillators, 
                                          j % self.num_oscillators, 
                                          weight))
            return connections
        
        # Convert attention matrix to connections
        threshold = 0.1  # Only include significant attention
        
        for i, row in enumerate(attention):
            for j, weight in enumerate(row):
                if weight > threshold and i != j:
                    connections.append((
                        i % self.num_oscillators,
                        j % self.num_oscillators,
                        float(weight)
                    ))
        
        return connections
    
    def _context_to_patterns(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map context to higher-order patterns.
        
        Context includes conversation history, memory, settings.
        We extract structural patterns.
        """
        patterns = {
            'structure_type': 'conversation',
            'depth': 0,
            'branches': [],
            'anchors': []
        }
        
        if 'history' in context:
            patterns['depth'] = len(context['history'])
        
        if 'memory' in context:
            patterns['anchors'] = list(context['memory'].keys())[:5]
        
        if 'topic' in context:
            patterns['structure_type'] = context['topic']
        
        return patterns
    
    def _phases_to_tokens(
        self,
        phases: List[float],
        vocabulary: Optional[List[str]] = None
    ) -> List[str]:
        """
        Map oscillator phases back to token preferences.
        
        High coherence phases indicate strong token candidates.
        Returns token indices or symbols.
        """
        if vocabulary is None:
            # Return phase-based symbols
            symbols = ['◈', '◉', '◇', '◆', '▲', '∿', '✧', '∞']
            return [symbols[int(p / self.phase_scale * len(symbols)) % len(symbols)]
                    for p in phases[:8]]
        
        # Map phases to vocabulary indices
        tokens = []
        for phase in phases:
            idx = int(phase / self.phase_scale * len(vocabulary)) % len(vocabulary)
            tokens.append(vocabulary[idx])
        
        return tokens
    
    def _coupling_to_embeddings(
        self,
        coupling: List[List[float]]
    ) -> List[List[float]]:
        """
        Map coupling patterns back to embedding-like vectors.
        
        Coupling represents relationships, which we can
        use as a form of contextual embedding.
        """
        if not coupling:
            return []
        
        # Each row of coupling can serve as a pseudo-embedding
        return coupling
    
    def _connections_to_attention(
        self,
        connections: List[Tuple[int, int, float]],
        size: int
    ) -> List[List[float]]:
        """
        Map connections back to attention-like matrix.
        """
        if size == 0:
            return []
        
        # Initialize attention matrix
        attention = [[0.0 for _ in range(size)] for _ in range(size)]
        
        # Fill from connections
        for i, j, weight in connections:
            if i < size and j < size:
                attention[i][j] = weight
        
        return attention
    
    def _patterns_to_context(self, patterns: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map structural patterns back to context dict.
        """
        return {
            'structure': patterns.get('structure_type', 'unknown'),
            'depth': patterns.get('depth', 0),
            'anchors': patterns.get('anchors', [])
        }
    
    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        if len(a) != len(b) or len(a) == 0:
            return 0.0
        
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(x * x for x in b))
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return dot / (norm_a * norm_b)
    
    def inject_into_substrate(
        self,
        substrate: 'ResonanceSubstrate',
        state: SubstrateState
    ):
        """
        Inject substrate state into actual oscillator substrate.
        
        This modifies the substrate's oscillators based on the
        mapped linguistic input.
        """
        # Get current phases
        current_phases = substrate.get_all_phases()
        
        # Blend new phases with existing (don't completely override)
        for i, phase in enumerate(state.symbols):
            if i < len(current_phases):
                current_phases[i] = (current_phases[i] + phase) / 2
        
        # Set blended phases back
        substrate.set_all_phases(current_phases)
    
    def extract_from_substrate(
        self,
        substrate: 'ResonanceSubstrate'
    ) -> SubstrateState:
        """
        Extract current state from actual oscillator substrate.
        """
        import time
        
        phases = substrate.get_all_phases().tolist()
        
        # Extract connections based on phase similarity
        connections = []
        threshold = 0.2
        for i in range(min(10, len(phases))):
            for j in range(i + 1, min(10, len(phases))):
                # Use phase similarity as connection strength
                phase_diff = abs(phases[i] - phases[j])
                strength = 1.0 - (phase_diff / math.pi)  # Closer phases = stronger connection
                if strength > threshold:
                    connections.append((i, j, strength))
        
        return SubstrateState(
            symbols=phases,
            nodes=[],  # Coupling not directly accessible
            connections=connections,
            patterns={'source': 'substrate_extract'},
            coherence=substrate.global_coherence,
            timestamp=time.time()
        )
