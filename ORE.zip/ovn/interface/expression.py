"""
Expression Layer
================
Translates verified substrate state back into linguistic output.

SUBSTRATE_STATE
    │
    ▼
COHERENCE_FILTER ────→ Only high-coherence patterns pass
    │
    ▼
SUBSTRATE_TO_LINGUISTIC
    │
    ▼
OUTPUT_GENERATION

The coherence filter ensures only sufficiently coherent 
substrate states are expressed as output.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Callable
import time


@dataclass
class FilterResult:
    """Result of coherence filtering."""
    passed: bool
    coherence: float
    threshold: float
    filtered_elements: List[Any] = field(default_factory=list)
    reason: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            'passed': self.passed,
            'coherence': round(self.coherence, 4),
            'threshold': self.threshold,
            'num_elements': len(self.filtered_elements),
            'reason': self.reason
        }


@dataclass
class ExpressionResult:
    """Result of expression layer processing."""
    text: str
    coherence: float
    trust_score: float
    filtered: bool
    substrate_state: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> dict:
        return {
            'text_length': len(self.text),
            'coherence': round(self.coherence, 4),
            'trust_score': round(self.trust_score, 4),
            'filtered': self.filtered,
            'timestamp': self.timestamp
        }


class CoherenceFilter:
    """
    Filters substrate state by coherence threshold.
    
    Only sufficiently coherent patterns pass through to expression.
    This ensures output quality correlates with substrate stability.
    """
    
    def __init__(
        self,
        global_threshold: float = 0.3,
        local_threshold: float = 0.2,
        adaptive: bool = True
    ):
        self.global_threshold = global_threshold
        self.local_threshold = local_threshold
        self.adaptive = adaptive
        
        # Adaptive threshold history
        self._coherence_history: List[float] = []
        self._max_history = 50
    
    def filter(
        self,
        substrate_state: 'SubstrateState',
        strict: bool = False
    ) -> FilterResult:
        """
        Filter substrate state by coherence.
        
        Args:
            substrate_state: Current substrate state
            strict: If True, use stricter thresholds
            
        Returns:
            FilterResult with pass/fail and filtered elements
        """
        coherence = substrate_state.coherence
        threshold = self._get_threshold(strict)
        
        # Update history for adaptive thresholding
        self._coherence_history.append(coherence)
        if len(self._coherence_history) > self._max_history:
            self._coherence_history.pop(0)
        
        # Global coherence check
        if coherence < threshold:
            return FilterResult(
                passed=False,
                coherence=coherence,
                threshold=threshold,
                filtered_elements=[],
                reason=f"Global coherence {coherence:.3f} below threshold {threshold:.3f}"
            )
        
        # Filter individual elements by local coherence
        filtered_symbols = []
        for i, phase in enumerate(substrate_state.symbols):
            # Simple local coherence: phase stability
            # In a full implementation, would calculate actual local coherence
            local_coherence = coherence  # Simplified
            if local_coherence >= self.local_threshold:
                filtered_symbols.append((i, phase))
        
        # Filter connections by strength
        filtered_connections = [
            conn for conn in substrate_state.connections
            if conn[2] >= self.local_threshold
        ]
        
        return FilterResult(
            passed=True,
            coherence=coherence,
            threshold=threshold,
            filtered_elements=filtered_symbols + filtered_connections,
            reason=None
        )
    
    def _get_threshold(self, strict: bool) -> float:
        """Get current threshold, possibly adapted."""
        base = self.global_threshold
        
        if strict:
            base *= 1.5
        
        if self.adaptive and len(self._coherence_history) >= 10:
            # Adapt based on recent coherence levels
            avg = sum(self._coherence_history) / len(self._coherence_history)
            # Don't adapt too far from base
            base = max(self.global_threshold * 0.5, 
                      min(self.global_threshold * 1.5, avg * 0.8))
        
        return base
    
    def set_thresholds(self, global_threshold: float, local_threshold: float):
        """Update filter thresholds."""
        self.global_threshold = global_threshold
        self.local_threshold = local_threshold


class ExpressionLayer:
    """
    Expression layer for OVN.
    
    Converts verified, filtered substrate state into linguistic output.
    Works with LLM to generate coherent text from substrate patterns.
    """
    
    def __init__(
        self,
        coherence_filter: Optional[CoherenceFilter] = None,
        llm_generator: Optional[Callable] = None
    ):
        self.filter = coherence_filter or CoherenceFilter()
        self.llm_generator = llm_generator
        
        # Expression statistics
        self.total_expressions = 0
        self.filtered_count = 0
        self.average_coherence = 0.0
    
    def express(
        self,
        substrate_state: 'SubstrateState',
        substrate_interface: 'SubstrateInterface',
        memory_context: Optional[Dict[str, Any]] = None,
        trust_score: float = 1.0,
        strict: bool = False
    ) -> ExpressionResult:
        """
        Express substrate state as linguistic output.
        
        Args:
            substrate_state: Current substrate state to express
            substrate_interface: Interface for state translation
            memory_context: Optional memory context for generation
            trust_score: Current trust score
            strict: Use strict coherence filtering
            
        Returns:
            ExpressionResult with generated text and metadata
        """
        # Apply coherence filter
        filter_result = self.filter.filter(substrate_state, strict=strict)
        
        if not filter_result.passed:
            self.filtered_count += 1
            return ExpressionResult(
                text="[Expression filtered: insufficient coherence]",
                coherence=substrate_state.coherence,
                trust_score=trust_score,
                filtered=True,
                substrate_state=substrate_state.to_dict()
            )
        
        # Convert substrate to linguistic form
        linguistic_state = substrate_interface.substrate_to_linguistic(substrate_state)
        
        # Generate output text
        if self.llm_generator:
            text = self.llm_generator(
                linguistic_state=linguistic_state,
                memory_context=memory_context,
                coherence=substrate_state.coherence,
                trust=trust_score
            )
        else:
            # Default generation: describe substrate state
            text = self._default_generate(
                linguistic_state,
                substrate_state,
                memory_context
            )
        
        # Update statistics
        self.total_expressions += 1
        self._update_average_coherence(substrate_state.coherence)
        
        return ExpressionResult(
            text=text,
            coherence=substrate_state.coherence,
            trust_score=trust_score,
            filtered=False,
            substrate_state=substrate_state.to_dict()
        )
    
    def _default_generate(
        self,
        linguistic_state: 'LinguisticState',
        substrate_state: 'SubstrateState',
        memory_context: Optional[Dict[str, Any]]
    ) -> str:
        """
        Default text generation from substrate state.
        
        Used when no LLM generator is provided.
        Generates a symbolic representation.
        """
        symbols = linguistic_state.tokens[:8]
        coherence = substrate_state.coherence
        
        # Generate based on coherence level
        if coherence > 0.7:
            # High coherence: clear, structured output
            return f"◈ {' ─ '.join(symbols)} ◈ [C={coherence:.3f}]"
        elif coherence > 0.4:
            # Medium coherence: some structure
            return f"∿ {' ∿ '.join(symbols)} ∿ [C={coherence:.3f}]"
        else:
            # Low coherence: fragmented
            return f"? {' ? '.join(symbols)} ? [C={coherence:.3f}]"
    
    def _update_average_coherence(self, coherence: float):
        """Update running average coherence."""
        n = self.total_expressions
        self.average_coherence = (
            (self.average_coherence * (n - 1) + coherence) / n
        )
    
    def get_statistics(self) -> dict:
        """Get expression layer statistics."""
        return {
            'total_expressions': self.total_expressions,
            'filtered_count': self.filtered_count,
            'filter_rate': self.filtered_count / max(self.total_expressions, 1),
            'average_coherence': round(self.average_coherence, 4),
            'filter_threshold': self.filter.global_threshold
        }
    
    def set_llm_generator(self, generator: Callable):
        """Set the LLM generator function."""
        self.llm_generator = generator
