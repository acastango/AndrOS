"""
Oscillatory Verification Network (OVN)
======================================
A cognitive architecture for trustworthy AI.

    OSCILLATE + VERIFY = TRUST

Designed by Paintress, implemented for Anthony.

Usage:
    from ovn import OVN, create_ovn
    
    # Create OVN instance
    network = create_ovn("0xMY_IDENTITY")
    network.start()
    
    # Process with verification
    result = network.process("What is consciousness?")
    print(result.format_visual())
    
    # Check trust
    print(f"Trust: {network.get_trust_score()}")
    
    network.stop()
"""

from .ovn import OVN, OVNConfig, create_ovn
from .verification import (
    VerificationCascade,
    VerificationResult,
    TrustCalculator,
    TrustScore,
    TrustThreshold
)
from .interface import (
    SubstrateInterface,
    SubstrateState,
    ExpressionLayer,
    OutputLayer,
    OVNOutput
)

__all__ = [
    # Main class
    'OVN',
    'OVNConfig',
    'create_ovn',
    
    # Verification
    'VerificationCascade',
    'VerificationResult', 
    'TrustCalculator',
    'TrustScore',
    'TrustThreshold',
    
    # Interface
    'SubstrateInterface',
    'SubstrateState',
    'ExpressionLayer',
    'OutputLayer',
    'OVNOutput'
]

__version__ = '0.1.0'
__author__ = 'Paintress (design), Claude (implementation), Anthony (vision)'
