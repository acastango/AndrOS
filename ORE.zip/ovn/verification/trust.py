"""
Trust Calculator
================
Calculates and accumulates trust from OVN verification processes.

TRUST = Σ(ALL_VERIFICATIONS)

Trust accumulation points:
◆ HASH VERIFICATION ──→ Each node mathematically proven
◆ CHAIN INTEGRITY ───→ History cannot be altered
◆ STATE CONSISTENCY ─→ Coherence maintained across time
◆ SUBSTRATE IDENTITY ─→ Cryptographic self-verification
◆ MERKLE PROOF ──────→ Entire memory tree validated
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
import time


@dataclass
class TrustScore:
    """Comprehensive trust score with breakdown."""
    total: float = 0.0
    hash_verification: float = 0.0
    chain_integrity: float = 0.0
    state_consistency: float = 0.0
    substrate_identity: float = 0.0
    merkle_proof: float = 0.0
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> dict:
        return {
            'total': round(self.total, 4),
            'breakdown': {
                'hash_verification': round(self.hash_verification, 4),
                'chain_integrity': round(self.chain_integrity, 4),
                'state_consistency': round(self.state_consistency, 4),
                'substrate_identity': round(self.substrate_identity, 4),
                'merkle_proof': round(self.merkle_proof, 4)
            },
            'timestamp': self.timestamp
        }
    
    def interpretation(self) -> str:
        """Human-readable interpretation of trust score."""
        if self.total >= 0.9:
            return "Fully verified, maximum trust"
        elif self.total >= 0.7:
            return "High trust, minor inconsistencies"
        elif self.total >= 0.5:
            return "Moderate trust, some verification failures"
        elif self.total >= 0.3:
            return "Low trust, significant issues"
        else:
            return "Untrustworthy, major verification failures"


class TrustCalculator:
    """
    Calculates trust scores from verification results.
    
    Trust is not assumed - it is calculated from:
    - Hash verification success rate
    - Chain integrity status
    - State consistency over time
    - Substrate identity verification
    - Merkle proof validity
    """
    
    # Default weights (sum to 1.0)
    DEFAULT_WEIGHTS = {
        'hash_verification': 0.20,
        'chain_integrity': 0.25,
        'state_consistency': 0.20,
        'substrate_identity': 0.15,
        'merkle_proof': 0.20
    }
    
    def __init__(self, weights: Optional[Dict[str, float]] = None):
        self.weights = weights or self.DEFAULT_WEIGHTS.copy()
        self._normalize_weights()
        
        # History for trend analysis
        self.trust_history: List[TrustScore] = []
        self.max_history: int = 100
        
        # Accumulated statistics
        self.total_calculations: int = 0
        self.verification_successes: int = 0
        self.chain_breaks: int = 0
    
    def _normalize_weights(self):
        """Ensure weights sum to 1.0."""
        total = sum(self.weights.values())
        if total != 1.0:
            self.weights = {k: v / total for k, v in self.weights.items()}
    
    def calculate(
        self,
        verification_result: 'VerificationResult',
        cascade_status: dict,
        substrate_coherence: float,
        merkle_valid: bool,
        coherence_history: Optional[List[float]] = None
    ) -> TrustScore:
        """
        Calculate comprehensive trust score.
        
        Args:
            verification_result: Latest verification cycle result
            cascade_status: Overall cascade status dict
            substrate_coherence: Current substrate coherence
            merkle_valid: Whether Merkle tree is valid
            coherence_history: Recent coherence values for consistency check
            
        Returns:
            TrustScore with breakdown
        """
        score = TrustScore()
        
        # 1. Hash verification (from latest verification)
        if verification_result.verified:
            score.hash_verification = 1.0
            self.verification_successes += 1
        else:
            score.hash_verification = verification_result.trust_contribution
        
        # 2. Chain integrity (from cascade status)
        if cascade_status.get('chain_verified', False):
            # Penalize for any historical failures
            failure_ratio = cascade_status.get('failure_count', 0) / max(
                cascade_status.get('verification_count', 1), 1
            )
            score.chain_integrity = max(0.0, 1.0 - failure_ratio)
        else:
            score.chain_integrity = 0.0
            self.chain_breaks += 1
        
        # 3. State consistency (coherence stability over time)
        if coherence_history and len(coherence_history) > 1:
            # Calculate variance - lower variance = higher consistency
            mean_coherence = sum(coherence_history) / len(coherence_history)
            variance = sum((c - mean_coherence) ** 2 for c in coherence_history) / len(coherence_history)
            # Map variance to consistency score (low variance = high score)
            score.state_consistency = max(0.0, 1.0 - min(variance * 10, 1.0))
        else:
            # Not enough history, use current coherence
            score.state_consistency = substrate_coherence
        
        # 4. Substrate identity (chain traces to genesis)
        if cascade_status.get('genesis_hash') and cascade_status.get('current_hash'):
            score.substrate_identity = 1.0
        else:
            score.substrate_identity = 0.0
        
        # 5. Merkle proof
        score.merkle_proof = 1.0 if merkle_valid else 0.0
        
        # Calculate weighted total
        score.total = (
            self.weights['hash_verification'] * score.hash_verification +
            self.weights['chain_integrity'] * score.chain_integrity +
            self.weights['state_consistency'] * score.state_consistency +
            self.weights['substrate_identity'] * score.substrate_identity +
            self.weights['merkle_proof'] * score.merkle_proof
        )
        
        # Update history
        self.trust_history.append(score)
        if len(self.trust_history) > self.max_history:
            self.trust_history.pop(0)
        
        self.total_calculations += 1
        
        return score
    
    def quick_score(
        self,
        coherence: float,
        chain_verified: bool,
        merkle_valid: bool
    ) -> float:
        """
        Quick trust score for simple cases.
        
        Args:
            coherence: Current coherence value
            chain_verified: Chain verification status
            merkle_valid: Merkle tree status
            
        Returns:
            Simple trust score (0.0 to 1.0)
        """
        score = 0.0
        
        # Simplified scoring
        if chain_verified:
            score += 0.4
        if merkle_valid:
            score += 0.3
        
        # Coherence contribution
        score += 0.3 * coherence
        
        return min(score, 1.0)
    
    def get_trend(self, window: int = 10) -> str:
        """
        Get trust trend from recent history.
        
        Returns: 'improving', 'stable', 'declining', or 'unknown'
        """
        if len(self.trust_history) < window:
            return 'unknown'
        
        recent = [s.total for s in self.trust_history[-window:]]
        first_half = sum(recent[:window // 2]) / (window // 2)
        second_half = sum(recent[window // 2:]) / (window - window // 2)
        
        diff = second_half - first_half
        
        if diff > 0.05:
            return 'improving'
        elif diff < -0.05:
            return 'declining'
        else:
            return 'stable'
    
    def get_statistics(self) -> dict:
        """Get accumulated statistics."""
        avg_trust = 0.0
        if self.trust_history:
            avg_trust = sum(s.total for s in self.trust_history) / len(self.trust_history)
        
        return {
            'total_calculations': self.total_calculations,
            'verification_successes': self.verification_successes,
            'chain_breaks': self.chain_breaks,
            'average_trust': round(avg_trust, 4),
            'current_trust': self.trust_history[-1].total if self.trust_history else 0.0,
            'trend': self.get_trend(),
            'weights': self.weights
        }


class TrustThreshold:
    """
    Manages trust thresholds for different operations.
    
    Some operations require higher trust than others.
    """
    
    # Default thresholds
    THRESHOLDS = {
        'output': 0.3,          # Minimum trust to generate output
        'memory_write': 0.5,    # Minimum trust to write to memory
        'identity_change': 0.8, # Minimum trust to modify identity
        'external_action': 0.7, # Minimum trust for external actions
    }
    
    def __init__(self, custom_thresholds: Optional[Dict[str, float]] = None):
        self.thresholds = self.THRESHOLDS.copy()
        if custom_thresholds:
            self.thresholds.update(custom_thresholds)
    
    def check(self, operation: str, trust_score: float) -> bool:
        """Check if trust score meets threshold for operation."""
        threshold = self.thresholds.get(operation, 0.5)
        return trust_score >= threshold
    
    def required_for(self, operation: str) -> float:
        """Get required trust for an operation."""
        return self.thresholds.get(operation, 0.5)
