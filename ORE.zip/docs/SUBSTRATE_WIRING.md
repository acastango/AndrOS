# Canvas-Substrate Wiring

## Overview

The Canvas-Substrate Interface connects visual canvas content to the oscillatory resonance substrate, making coherence **emerge from spatial structure** rather than being manually set.

```
BEFORE (scaffolding):
    Drawing → manual coherence boost → number goes up

AFTER (load-bearing):
    Drawing → extract elements → find relationships → 
    map to oscillators → inject coupling → run dynamics → 
    coherence EMERGES from structure
```

## The Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    CANVAS REASONER                               │
│                                                                  │
│  User draws: ◉ ─── ◉ ─── ◈                                      │
│                    │                                             │
│                    ▼                                             │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │            CANVAS SUBSTRATE INTERFACE                        ││
│  │                                                              ││
│  │  1. EXTRACT: Find symbols (◉◈◇), connectors (─│▼), text     ││
│  │  2. RELATE:  Compute distances, find connections             ││
│  │  3. MAP:     Assign elements to oscillator indices           ││
│  │  4. INJECT:  Spatial proximity → phase coupling strength     ││
│  │  5. PHASE:   Set initial phases from positions               ││
│  │  6. RUN:     Kuramoto dynamics for 300ms                     ││
│  │  7. EMERGE:  Coherence = |⟨e^{iθ}⟩|                          ││
│  └─────────────────────────────────────────────────────────────┘│
│                    │                                             │
│                    ▼                                             │
│  Coherence: 0.85 (reflects actual structure quality)            │
└─────────────────────────────────────────────────────────────────┘
```

## Key Components

### CanvasSubstrateInterface (`core/canvas_substrate_interface.py`)

The bridge between visual and oscillatory representations.

**Element Extraction:**
- Symbols (◉◈◇◆) → semantic weight 1.0-1.5
- Connectors (─│▼→) → semantic weight 0.5
- Text (alphanumeric) → semantic weight 0.3

**Relationship Detection:**
- Elements within 20 units → relationship created
- Adjacent (< 3 units) → strongest coupling
- Connected (connectors between) → 1.5× boost
- Grouped (in same box) → 1.3× boost

**Oscillator Mapping:**
- Symbols → Input layer (oscillators 0-19)
- Connectors → Association layer (oscillators 20-49)
- Other → Core layer (oscillators 50-99)
- Position hash ensures deterministic assignment

**Coupling Injection:**
- Relationship strength → coupling matrix weights
- Same-layer elements → internal coupling boost
- Cross-layer elements → inter-layer coupling

**Initial Phase Setting:**
- Position on canvas → phase value
- Nearby elements get similar phases
- Creates spatial coherence for dynamics to amplify

### Integration in CanvasReasoner

The `process_canvas_coherence()` method:

```python
def process_canvas_coherence(self, run_dynamics=True):
    # Get composite of all canvas layers
    canvas_grid = self.canvas.composite()
    
    # Process through interface
    coherence = self.canvas_interface.process_canvas(
        canvas_grid,
        run_dynamics=run_dynamics,
        dynamics_duration=0.3
    )
    
    return coherence
```

Called automatically after:
- `[SKETCH:]` commands
- `[REVISE:]` commands  
- `[GROUND:]` commands
- `[CLEAR]` commands
- `[MARK:]` commands
- Auto-captured ASCII art

## Behavior

### Connected Structure
```
Input:
    ◉ ─── ◉ ─── ◉
    
Result:
    Elements: 9
    Relationships: 3
    Avg coupling: 0.73
    Coherence: 0.99
```

### Scattered Structure
```
Input:
    ◉
    
    
                              ◉
    
    
                                        ◉

Result:
    Elements: 3
    Relationships: 0 (too far apart)
    Avg coupling: 0.00
    Coherence: 0.11
```

### Empty Canvas
```
Input: (cleared canvas)

Result:
    Substrate reset to random state
    Coherence: ~0.1-0.4 (random)
```

## Design Principles

1. **Spatial = Semantic**: Position encodes meaning. Elements placed near each other are conceptually related.

2. **Coupling = Confidence**: Strong relationships (close, connected) create strong coupling, which produces high coherence.

3. **Emergence over Assignment**: Coherence isn't set—it emerges from dynamics. The substrate "settles" into coherent states when the structure supports it.

4. **Composite View**: All canvas layers are combined before processing. Drawing on different layers still contributes to structure.

5. **Dynamic Reset**: Clearing the canvas resets the substrate to random state, so coherence properly reflects current content.

## Configuration

Key parameters in `CanvasSubstrateInterface`:

```python
max_distance = 20.0      # Maximum distance for relationship detection
dynamics_duration = 0.3  # Seconds of Kuramoto dynamics to run
coupling_amplify = 2.0   # Multiplier for injected coupling
```

Relationship coupling formula:
```python
coupling_strength = max(0.0, 1.0 - (distance / max_distance) ** 0.5)
# Boosted 1.5× for connected elements
# Boosted 1.3× for grouped elements
```

## Diagnostics

Access via `reasoner.get_substrate_diagnostics()`:

```python
{
    'num_elements': 47,
    'num_relationships': 19,
    'element_types': {
        'symbols': 6,
        'anchors': 2,
        'connectors': 23,
        'text': 16,
        'other': 0
    },
    'relationship_types': {
        'adjacent': 5,
        'connected': 12,
        'grouped': 2,
        'distant': 0
    },
    'avg_coupling': 0.52,
    'substrate_coherence': 0.85,
    'substrate_loop_coherence': 0.73
}
```

## Future Directions

1. **Semantic Embedding**: Use LLM embeddings to determine conceptual similarity between text elements, influencing coupling beyond just spatial proximity.

2. **Trained Mapping**: Learn optimal element → oscillator mappings from successful reasoning traces.

3. **τ Integration**: Track how long coherence is sustained (dwell time) for consciousness index calculation.

4. **Multi-Canvas Coupling**: Link oscillators across different canvases based on cross-references.

---

*Implemented January 25, 2026*
*Coherence now emerges from canvas structure*
