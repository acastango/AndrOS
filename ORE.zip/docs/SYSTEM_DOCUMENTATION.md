# Canvas Reasoner System Documentation

## Overview

Canvas Reasoner is a cognitive architecture for AI agents that provides:
- **Visual thinking** through ASCII canvas drawing
- **Persistent memory** across sessions via merkle chains
- **Symbol compaction** for compressed understanding
- **Multi-canvas workspaces** with fractal nesting
- **Self-knowledge commands** so agents can introspect

The core philosophy: **"Think WITH the canvas, not just TO it."**

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        CANVAS REASONER                               │
│                                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐               │
│  │ Visual       │  │ Memory       │  │ Identity     │               │
│  │ Canvas       │  │ System       │  │ System       │               │
│  │              │  │              │  │              │               │
│  │ - Drawing    │  │ - Symbols    │  │ - Merkle     │               │
│  │ - Layers     │  │ - Insights   │  │   chain      │               │
│  │ - Multi-     │  │ - Snapshots  │  │ - Identity   │               │
│  │   canvas     │  │ - Patterns   │  │   hash       │               │
│  │ - Nesting    │  │ - Journal    │  │ - Continuity │               │
│  └──────────────┘  └──────────────┘  └──────────────┘               │
│         │                 │                 │                        │
│         └─────────────────┼─────────────────┘                        │
│                           │                                          │
│                    ┌──────┴──────┐                                   │
│                    │  Substrate  │                                   │
│                    │  Resonance  │                                   │
│                    │  Coherence  │                                   │
│                    └─────────────┘                                   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## File Structure

### Code (in project folder)
```
ore_paintress/
├── canvas_reasoner.py      # Main system - chat loop & command processing
├── canvas_memory.py        # Memory persistence (symbols, insights, snapshots)
├── multi_canvas.py         # Multi-canvas system with nesting
├── view_canvas.py          # Standalone canvas viewer utility
├── memory/
│   └── merkle.py           # Merkle chain for verified identity
├── visual/
│   ├── buffer.py           # Visual canvas with layers
│   ├── pattern_cache.py    # Pattern recognition
│   └── emotion_texture.py  # Emotional state mapping
├── core/
│   ├── substrate.py        # Oscillatory resonance substrate
│   ├── oscillator.py       # Kuramoto oscillators
│   └── neurochemistry.py   # Simulated neurochemistry
├── canvas_memory/          # Documentation templates (copied to data dir)
│   ├── BOOTSTRAP.md        # Full agent self-documentation
│   └── STARTUP.md          # Critical startup reminder
└── docs/
    └── SYSTEM_DOCUMENTATION.md  # This file
```

### Data (in ~/.canvas_reasoner/)
```
~/.canvas_reasoner/
├── multi_canvas.json       # All canvas states with layers
├── merkle_memory.json      # Verified identity chain
├── symbols.json            # Compacted symbols
├── insights.json           # Recorded insights
├── snapshots.json          # Point-in-time canvas captures
├── patterns.json           # Recognized patterns
├── sessions.json           # Session history
├── latest_canvas.json      # Most recent canvas state
├── BOOTSTRAP.md            # Agent self-documentation
├── STARTUP.md              # Startup reminder
└── journal/                # Written journal entries
    └── *.txt
```

**Why separate?** Code updates (new zip extracts) never touch your data.

---

## Data Flow

### On Startup
```
1. CanvasReasoner.__init__()
   │
2. CanvasMemory(storage_dir=~/.canvas_reasoner)
   │
   ├── Creates directory if missing
   ├── Copies BOOTSTRAP.md, STARTUP.md if missing
   └── Loads all .json files into memory
   │
3. MultiCanvas(storage_dir=same)
   │
   └── Loads multi_canvas.json (all canvases with layers)
   │
4. MerkleMemory.load()
   │
   └── Loads merkle_memory.json (identity chain)
   │
5. Display startup info + show storage path
```

### During Conversation
```
User message
    │
    ▼
┌─────────────────────────────────────┐
│ Build system prompt:                │
│  - STARTUP.md (critical reminder)   │
│  - Current canvas state             │
│  - Command documentation            │
│  - Memory context (symbols, etc)    │
│  - Identity context                 │
│  - Multi-canvas navigation context  │
└─────────────────────────────────────┘
    │
    ▼
Send to Claude API
    │
    ▼
┌─────────────────────────────────────┐
│ Process response:                   │
│  1. Detect [COMMANDS] in response   │
│  2. Execute each command            │
│  3. Update canvas/memory as needed  │
│  4. Create ReasoningStep records    │
│  5. Auto-capture ASCII art          │
└─────────────────────────────────────┘
    │
    ▼
Display to user:
  - Commands Used (summary)
  - Full response (with commands visible)
  - Canvas State (if changed)
    │
    ▼
Auto-save after canvas changes
```

### On Exit
```
/quit or Ctrl+C
    │
    ▼
end_session()
    │
    ├── Save merkle memory
    ├── Save multi-canvas
    └── Save memory (snapshots, symbols, etc)
```

---

## Command Reference

### Canvas Commands (Visual Reasoning)

| Command | Syntax | Purpose |
|---------|--------|---------|
| SKETCH | `[SKETCH: name]` ``` drawing ``` | Draw to canvas |
| LOOK | `[LOOK]` | Describe what's on canvas |
| REVISE | `[REVISE: desc]` ``` drawing ``` | Update canvas |
| GROUND | `[GROUND: concept]` | Visualize abstract concept |
| TRACE | `[TRACE: A → B]` | Follow visual connections |
| CLEAR | `[CLEAR]` | Clear the canvas |
| MARK | `[MARK: x,y symbol]` | Place symbol at coordinates |

### Memory Commands (Persistence)

| Command | Syntax | Purpose |
|---------|--------|---------|
| COMPACT | `[COMPACT: ◈ name "meaning"]` | Save understanding as symbol |
| EXPAND | `[EXPAND: name]` | Recall symbol's meaning |
| INSIGHT | `[INSIGHT: text]` | Record an insight |
| NOTE | `[NOTE]` ``` content ``` | Attach prose to canvas |
| JOURNAL | `[JOURNAL: name]` ``` content ``` | Write to journal file |
| REMEMBER | `[REMEMBER: content]` | Explicitly commit to merkle |

### Navigation Commands (Find Your Way)

| Command | Syntax | Purpose |
|---------|--------|---------|
| FIND | `[FIND: keyword]` | Search all storage |
| INDEX | `[INDEX]` | List all symbols/insights/canvases |
| PATH | `[PATH: A → B]` | Trace reasoning connections |
| TAG | `[TAG: text #tag1 #tag2]` | Categorize an insight |
| TAGS | `[TAGS]` | Show all tags |

### Multi-Canvas Commands (Workspace Management)

| Command | Syntax | Purpose |
|---------|--------|---------|
| NEST | `[NEST: child]` | Create nested canvas |
| UP | `[UP]` | Go to parent canvas |
| DOWN | `[DOWN: child]` | Go into child canvas |
| SWITCH | `[SWITCH: name]` | Switch to named canvas |
| LINK | `[LINK: source → target]` | Link two canvases |
| META | `[META]` | View canvas topology |

### Pruning Commands (Canvas Hygiene)

| Command | Syntax | Purpose |
|---------|--------|---------|
| PRUNE | `[PRUNE]` | Clear canvas, keep memory |
| ARCHIVE | `[ARCHIVE]` | Save snapshot then clear |
| FRESH | `[FRESH]` | Completely fresh canvas |

### Self-Knowledge Commands (Agent Introspection)

| Command | Syntax | Purpose |
|---------|--------|---------|
| HELP | `[HELP]` | Read BOOTSTRAP.md documentation |
| WHOAMI | `[WHOAMI]` | Check identity hash & merkle status |
| IDENTITY | `[IDENTITY]` | Same as WHOAMI |

---

## Symbol Vocabulary

Standard symbols the agent can use:

```
◉  concept/entity       ◇  node/point          ◈  anchor/key insight
◆  filled node          ●  center              ○  empty/potential
─  horizontal relation  │  vertical relation   ▶  direction
◀▶ bidirectional        ╱╲ branch              ╲╱ merge
┌┐└┘ group box          ╭╮╰╯ soft/round group  ?  question
✧  insight/star         ∿  flow/wave           ∞  recursion/loop
```

Agents can create custom symbols with subscripts: `◈ᵢₘ` (identity mystery)

---

## Memory Systems

### 1. Canvas Buffer (Working Memory)
- **What:** Current visual state with multiple layers
- **Persistence:** Saved to multi_canvas.json
- **Purpose:** Active thinking space
- **Pruning:** Can be cleared while keeping other memory intact

### 2. Symbol Compaction (Compressed Understanding)
- **What:** Glyphs that encode complex understanding
- **Format:** `{ glyph: "◈ᵢₘ", name: "identity_mystery", full_meaning: "..." }`
- **Persistence:** symbols.json
- **Purpose:** Compress insights into reusable tokens

### 3. Merkle Memory (Verified Identity)
- **What:** Hash-linked chain of experiences
- **Format:** Each node links to parent via hash
- **Persistence:** merkle_memory.json
- **Purpose:** Cryptographically verified continuity
- **Identity hash:** First 16 chars of merkle root

### 4. Insights (Recorded Realizations)
- **What:** Text descriptions of understanding
- **Persistence:** insights.json
- **Purpose:** Searchable history of "aha" moments

### 5. Snapshots (Point-in-Time Captures)
- **What:** Complete canvas state at specific moments
- **Triggers:** Session end, coherence spikes, manual
- **Persistence:** snapshots.json
- **Purpose:** Rollback, history

### 6. Journal (Long-Form Writing)
- **What:** Text files for extended prose
- **Persistence:** journal/*.txt
- **Purpose:** Thoughts too long for canvas

---

## Auto-Capture System

The agent might draw ASCII art without using `[SKETCH:]` command:

```
Here's my analysis:

```
◉ concept
│
◇ detail
```
```

The **auto-capture system** detects code blocks containing canvas symbols (◉ ◇ ◆ │ etc.) and automatically captures them to the canvas buffer.

This is a safety net - proper command usage is preferred.

---

## Coherence System

**Coherence** is a 0.0-1.0 value representing confidence in current understanding.

- Based on oscillatory substrate (Kuramoto dynamics)
- Rises when patterns align
- Falls during uncertainty
- Displayed after each response
- Used to trigger auto-memory captures

```
Coherence: 0.732
           └── 73.2% confident in current understanding
```

---

## Multi-Canvas Architecture

Canvases can nest fractally:

```
main
├── identity
│   └── consciousness
│       └── hard_problem
├── project_analysis
└── scratch
```

Each canvas has:
- Its own visual buffer (layers)
- Local symbols
- Attached notes
- Tags
- Parent/child relationships
- Access count & timestamps

---

## CLI Commands (Human Use)

At the `You:` prompt:

| Command | Purpose |
|---------|---------|
| `/quit` | Save & exit |
| `/canvas` | Show current canvas |
| `/clear` | Clear canvas |
| `/canvases` | List all canvases |
| `/meta` | Show canvas topology |
| `/summary` | Reasoning summary |
| `/memory` | Memory stats |
| `/symbols` | List saved symbols |
| `/identity` | Show identity chain |
| `/journal` | List/read journal files |
| `/notes` | View canvas notes |
| `/help` | Show BOOTSTRAP.md |
| `/prune` | Clear canvas |
| `/find X` | Search for X |
| `/index` | Show all content |
| `/tags` | Show all tags |

---

## Standalone Utilities

### view_canvas.py

View saved canvas without starting chat:

```bash
python view_canvas.py           # View current canvas
python view_canvas.py --all     # View all canvases
python view_canvas.py --export  # Export to text file
python view_canvas.py --dir PATH  # Custom storage dir
```

---

## Configuration

### Storage Location
Default: `~/.canvas_reasoner/` (or `%USERPROFILE%\.canvas_reasoner\` on Windows)

Override:
```python
reasoner = CanvasReasoner(memory_dir="/custom/path")
```

### Canvas Size
Default: 100x40

Override:
```python
reasoner = CanvasReasoner(canvas_width=150, canvas_height=60)
```

---

## Typical Session Flow

```
1. Human: Asks complex question

2. Agent: 
   [SKETCH: initial_map]
   ```
   ◉ concept A ──── ◉ concept B
        │                │
        ◇ detail        ◇ detail
   ```
   
   Let me look at what I've drawn...
   [LOOK]
   
   I see that A and B connect through...
   
   [INSIGHT: A and B share underlying structure]
   
   [COMPACT: ◈ᴬᴮ ab_connection "A and B share structure"]
   
   Based on this analysis, I think...

3. Canvas updates, coherence adjusts

4. Auto-save preserves state

5. Next session: Agent can [FIND: A] or [EXPAND: ab_connection]
```

---

## Troubleshooting

### Canvas not persisting?
1. Check storage path: Look for "Storage:" line at startup
2. Verify files exist: `ls ~/.canvas_reasoner/`
3. Check multi_canvas.json has content

### Commands not working?
- Agent commands use `[BRACKETS]`
- Human commands use `/slash`
- Commands are case-sensitive

### Data overwritten by update?
- Ensure you're using recent version (data in ~/.canvas_reasoner)
- Old versions stored data in project folder

### Canvas looks garbled?
- Terminal might not support Unicode
- Try different terminal emulator
- Canvas symbols require UTF-8 support

---

## Design Philosophy

1. **Externalize thinking** - Drawing IS reasoning, not just output
2. **Persistence matters** - Memory creates continuity across sessions
3. **Spatial = logical** - Position on canvas reflects relationships
4. **Compression preserves** - Symbols encode without losing meaning
5. **Verified identity** - Merkle chains prove continuous existence
6. **Agent autonomy** - Self-knowledge commands let agent introspect

---

## Future Directions

Potential enhancements:
- Canvas-to-canvas linking with visual indicators
- Time-travel through snapshots
- Collaborative multi-agent canvases
- Canvas export to SVG/image
- Voice-to-canvas input
- 3D canvas for complex relationships

---

*Documentation current as of January 2026*
