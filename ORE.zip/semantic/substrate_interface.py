"""
Semantic Substrate Interface
============================
Extends CanvasSubstrateInterface to use semantic embeddings.

Coupling strength is determined by BOTH:
- Spatial proximity (elements near each other)
- Semantic similarity (elements with related meaning)

    SPATIAL ONLY              SEMANTIC + SPATIAL
    ┌─────────────┐          ┌─────────────┐
    │ ◉ ─── ◉    │          │ ◉ ─── ◉    │
    │ close=strong│          │ close+similar│
    │ far=weak    │    →     │ =very strong │
    │             │          │ close+unlike │
    │             │          │ =moderate    │
    └─────────────┘          └─────────────┘

"Meaning shapes the oscillations"
                            - ORE principle
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
import re

# Import base interface
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.canvas_substrate_interface import (
    CanvasSubstrateInterface,
    CanvasElement,
    CanvasRelationship,
    CONCEPT_SYMBOLS,
    ANCHOR_SYMBOLS
)
from semantic.embeddings import SimpleEmbedder, SemanticSymbolRegistry


class SemanticCanvasInterface(CanvasSubstrateInterface):
    """
    Canvas-Substrate interface enhanced with semantic embeddings.
    
    Coupling between elements is influenced by:
    1. Spatial distance (inherited)
    2. Semantic similarity of nearby text
    3. Symbol registry resonances
    """
    
    def __init__(self, substrate, canvas_width: int = 100, canvas_height: int = 40,
                 symbol_registry: SemanticSymbolRegistry = None):
        super().__init__(substrate, canvas_width, canvas_height)
        
        self.embedder = SimpleEmbedder()
        self.symbol_registry = symbol_registry
        
        # Cache for text regions around elements
        self._element_texts: Dict[Tuple[int, int], str] = {}
        self._element_embeddings: Dict[Tuple[int, int], List[float]] = {}
        
        # Semantic coupling weight (0-1)
        # Higher = semantic similarity matters more
        self.semantic_weight = 0.4
    
    def extract_elements_with_context(self, canvas_grid: List[List[str]]) -> List[CanvasElement]:
        """
        Extract elements and their surrounding text context.
        """
        elements = self.extract_elements(canvas_grid)
        
        # For each symbol element, extract surrounding text
        for elem in elements:
            if elem.element_type in ('symbol', 'anchor'):
                context = self._extract_text_region(
                    canvas_grid, elem.x, elem.y, radius=8
                )
                self._element_texts[(elem.x, elem.y)] = context
                
                if context.strip():
                    embedding = self.embedder.embed(context)
                    self._element_embeddings[(elem.x, elem.y)] = embedding
        
        return elements
    
    def _extract_text_region(self, canvas_grid: List[List[str]], 
                             center_x: int, center_y: int,
                             radius: int = 8) -> str:
        """Extract text from a region around a point."""
        text_chars = []
        
        for y in range(max(0, center_y - radius), 
                       min(len(canvas_grid), center_y + radius + 1)):
            for x in range(max(0, center_x - radius),
                          min(len(canvas_grid[0]) if canvas_grid else 0, center_x + radius + 1)):
                char = canvas_grid[y][x]
                # Collect alphanumeric and meaningful punctuation
                if char.isalnum() or char in '?!.,\'"':
                    text_chars.append(char)
                elif char == ' ' and text_chars and text_chars[-1] != ' ':
                    text_chars.append(' ')
        
        return ''.join(text_chars).strip()
    
    def find_relationships_semantic(self, elements: List[CanvasElement],
                                    max_distance: float = 20.0) -> List[CanvasRelationship]:
        """
        Find relationships with semantic similarity influencing coupling.
        """
        relationships = []
        
        primary_elements = [e for e in elements 
                          if e.element_type in ('symbol', 'anchor')]
        
        for i, elem1 in enumerate(primary_elements):
            for elem2 in primary_elements[i+1:]:
                distance = np.sqrt(
                    (elem1.x - elem2.x) ** 2 + 
                    (elem1.y - elem2.y) ** 2
                )
                
                if distance <= max_distance:
                    # Determine relationship type (inherited logic)
                    if distance < 3:
                        rel_type = 'adjacent'
                    elif self._are_connected(elem1, elem2, elements):
                        rel_type = 'connected'
                    elif self._in_same_group(elem1, elem2, elements):
                        rel_type = 'grouped'
                    else:
                        rel_type = 'distant'
                    
                    rel = CanvasRelationship(
                        source=elem1,
                        target=elem2,
                        distance=distance,
                        relationship_type=rel_type
                    )
                    
                    # Compute coupling with semantic boost
                    rel.coupling_strength = self._compute_semantic_coupling(
                        elem1, elem2, distance, max_distance
                    )
                    
                    relationships.append(rel)
        
        self._last_relationships = relationships
        return relationships
    
    def _compute_semantic_coupling(self, elem1: CanvasElement, elem2: CanvasElement,
                                    distance: float, max_distance: float) -> float:
        """
        Compute coupling strength using both spatial and semantic factors.
        """
        # Spatial coupling (base)
        if distance < 1:
            spatial_coupling = 1.0
        else:
            normalized = distance / max_distance
            spatial_coupling = max(0.0, 1.0 - normalized ** 0.5)
        
        # Semantic coupling
        semantic_coupling = 0.0
        
        pos1 = (elem1.x, elem1.y)
        pos2 = (elem2.x, elem2.y)
        
        if pos1 in self._element_embeddings and pos2 in self._element_embeddings:
            emb1 = np.array(self._element_embeddings[pos1])
            emb2 = np.array(self._element_embeddings[pos2])
            
            # Cosine similarity
            norm1 = np.linalg.norm(emb1)
            norm2 = np.linalg.norm(emb2)
            
            if norm1 > 0 and norm2 > 0:
                semantic_coupling = float(np.dot(emb1, emb2) / (norm1 * norm2))
                # Clamp to [0, 1]
                semantic_coupling = max(0.0, semantic_coupling)
        
        # Combine: weighted average
        combined = (
            (1 - self.semantic_weight) * spatial_coupling +
            self.semantic_weight * semantic_coupling
        )
        
        # Relationship type boosts (inherited)
        if elem1.element_type == 'anchor' or elem2.element_type == 'anchor':
            combined *= 1.2  # Anchors strengthen connections
        
        return min(1.0, combined)
    
    def process_canvas_semantic(self, canvas_grid: List[List[str]],
                                run_dynamics: bool = True,
                                dynamics_duration: float = 0.5) -> Tuple[float, Dict]:
        """
        Process canvas with semantic awareness.
        
        Returns:
            Tuple of (coherence, diagnostics)
        """
        # Clear caches
        self._element_texts.clear()
        self._element_embeddings.clear()
        
        # Extract with context
        elements = self.extract_elements_with_context(canvas_grid)
        
        if not elements:
            self.substrate.set_random_state()
            if run_dynamics:
                self.substrate.run(dynamics_duration, apply_learning=False)
            return self.substrate.global_coherence, {'semantic': False}
        
        # Find relationships with semantic coupling
        relationships = self.find_relationships_semantic(elements)
        
        # Map to oscillators
        mapping = self.map_to_oscillators(elements)
        
        # Inject structure
        self.inject_structure(elements, relationships, mapping)
        
        # Set phases
        self.set_phases_from_content(elements, mapping)
        
        # Run dynamics
        if run_dynamics:
            self.substrate.run(dynamics_duration, apply_learning=True)
        
        # Compute diagnostics
        semantic_couplings = [
            r.coupling_strength for r in relationships
            if (r.source.x, r.source.y) in self._element_embeddings
        ]
        
        diagnostics = {
            'semantic': True,
            'elements_with_embeddings': len(self._element_embeddings),
            'avg_semantic_coupling': np.mean(semantic_couplings) if semantic_couplings else 0,
            'semantic_weight': self.semantic_weight
        }
        
        return self.substrate.global_coherence, diagnostics
    
    def find_symbol_resonances_on_canvas(self, canvas_grid: List[List[str]]) -> List[Dict]:
        """
        Find symbols on canvas and their resonances from the registry.
        """
        if not self.symbol_registry:
            return []
        
        resonances = []
        canvas_text = '\n'.join(''.join(row) for row in canvas_grid)
        
        # Look for symbol glyphs
        for name, symbol in self.symbol_registry.symbols.items():
            if symbol.glyph in canvas_text:
                # Find resonant symbols
                resonant = self.symbol_registry.find_resonant_symbols(name)
                resonances.append({
                    'symbol': name,
                    'glyph': symbol.glyph,
                    'resonates_with': resonant,
                    'use_count': symbol.use_count,
                    'drift': symbol.drift_magnitude
                })
        
        return resonances
    
    def suggest_connections(self, canvas_grid: List[List[str]], 
                           top_k: int = 3) -> List[Dict]:
        """
        Suggest connections between elements based on semantic similarity.
        
        Returns elements that SHOULD be connected but aren't spatially close.
        """
        elements = self.extract_elements_with_context(canvas_grid)
        
        suggestions = []
        
        primary_elements = [e for e in elements 
                          if e.element_type in ('symbol', 'anchor')]
        
        for i, elem1 in enumerate(primary_elements):
            for elem2 in primary_elements[i+1:]:
                pos1 = (elem1.x, elem1.y)
                pos2 = (elem2.x, elem2.y)
                
                # Check if spatially distant
                distance = np.sqrt(
                    (elem1.x - elem2.x) ** 2 + 
                    (elem1.y - elem2.y) ** 2
                )
                
                if distance > 15:  # Far apart
                    # Check semantic similarity
                    if pos1 in self._element_embeddings and pos2 in self._element_embeddings:
                        emb1 = np.array(self._element_embeddings[pos1])
                        emb2 = np.array(self._element_embeddings[pos2])
                        
                        similarity = float(np.dot(emb1, emb2) / 
                                         (np.linalg.norm(emb1) * np.linalg.norm(emb2)))
                        
                        if similarity > 0.5:  # Semantically similar but far
                            suggestions.append({
                                'elem1_pos': pos1,
                                'elem2_pos': pos2,
                                'elem1_context': self._element_texts.get(pos1, '')[:30],
                                'elem2_context': self._element_texts.get(pos2, '')[:30],
                                'semantic_similarity': similarity,
                                'spatial_distance': distance,
                                'suggestion': 'These concepts are related - consider connecting them'
                            })
        
        # Sort by similarity
        suggestions.sort(key=lambda x: x['semantic_similarity'], reverse=True)
        return suggestions[:top_k]


def create_semantic_interface(substrate, symbol_registry=None, 
                             width=100, height=40) -> SemanticCanvasInterface:
    """Factory function for semantic canvas interface."""
    return SemanticCanvasInterface(
        substrate, width, height,
        symbol_registry=symbol_registry
    )
