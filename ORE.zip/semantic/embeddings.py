"""
Semantic Embeddings for Symbols
===============================
Symbols become vectors in meaning space, not just text labels.

    TEXT SYMBOL                    SEMANTIC SYMBOL
    ┌─────────────┐               ┌─────────────────────────┐
    │ ◈ᵢₘ        │               │ ◈ᵢₘ                     │
    │ "identity  │      →        │ embedding: [0.23, ...]  │
    │  mystery"  │               │ contexts: [...]         │
    │             │               │ resonates_with: [◈ᵉᵇ]  │
    └─────────────┘               └─────────────────────────┘

Symbols evolve with use. Meaning drifts. Understanding deepens.

"The symbol carries its history in its vector"
                                    - ORE principle
"""

import numpy as np
import hashlib
import json
import os
import time
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple, Any


# Embedding dimensions (can be configured)
EMBEDDING_DIM = 384  # Smaller than OpenAI's 1536, but sufficient for local use


@dataclass
class SemanticSymbol:
    """
    A symbol with semantic embedding that evolves with use.
    """
    glyph: str                    # Visual representation: ◈ᵢₘ
    name: str                     # Identifier: "identity_mystery"
    text_meaning: str             # Human-readable: "the question of who observes"
    
    # Semantic embedding
    embedding: List[float] = field(default_factory=list)
    
    # Context tracking - embeddings of contexts where this symbol was used
    creation_context_embedding: List[float] = field(default_factory=list)
    usage_context_embeddings: List[List[float]] = field(default_factory=list)
    
    # Metadata
    created_at: float = field(default_factory=time.time)
    use_count: int = 0
    coherence_at_creation: float = 0.0
    canvas_name_at_creation: str = ""
    
    # Relationships (discovered through embedding similarity)
    resonates_with: List[str] = field(default_factory=list)  # symbol names
    resonance_strengths: Dict[str, float] = field(default_factory=dict)
    
    # Evolution tracking
    embedding_history: List[Tuple[float, List[float]]] = field(default_factory=list)
    drift_magnitude: float = 0.0  # How much has meaning shifted?
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'SemanticSymbol':
        return cls(**data)
    
    def update_embedding(self, new_context_embedding: List[float], 
                         learning_rate: float = 0.1):
        """
        Update symbol's embedding based on new usage context.
        Symbols drift toward the contexts where they're used.
        """
        if not self.embedding:
            # First usage - just adopt the context
            self.embedding = new_context_embedding
            return
        
        # Record history before update
        self.embedding_history.append((time.time(), self.embedding.copy()))
        
        # Blend current embedding with new context
        old_embedding = np.array(self.embedding)
        new_embedding = np.array(new_context_embedding)
        
        updated = (1 - learning_rate) * old_embedding + learning_rate * new_embedding
        
        # Track drift
        drift = np.linalg.norm(updated - old_embedding)
        self.drift_magnitude = float(drift)
        
        self.embedding = updated.tolist()
        self.usage_context_embeddings.append(new_context_embedding)
        self.use_count += 1
    
    def similarity_to(self, other_embedding: List[float]) -> float:
        """Compute cosine similarity to another embedding."""
        if not self.embedding or not other_embedding:
            return 0.0
        
        a = np.array(self.embedding)
        b = np.array(other_embedding)
        
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return float(np.dot(a, b) / (norm_a * norm_b))


class SimpleEmbedder:
    """
    Simple embedding generator that doesn't require external APIs.
    Uses hash-based projection for deterministic embeddings.
    
    WARNING: This does NOT capture real semantic similarity!
    Use SentenceTransformerEmbedder or OpenAI embeddings for production.
    """
    
    def __init__(self, dim: int = EMBEDDING_DIM):
        self.dim = dim
        # Fixed random projection matrix (seeded for consistency)
        np.random.seed(42)
        self.projection = np.random.randn(10000, dim) / np.sqrt(dim)
    
    def embed(self, text: str) -> List[float]:
        """
        Generate embedding for text.
        
        Uses bag-of-words + hash projection for simplicity.
        Replace with real embeddings for production.
        """
        # Tokenize simply
        words = text.lower().split()
        
        # Build sparse bag-of-words
        word_indices = []
        for word in words:
            # Hash word to index
            h = int(hashlib.md5(word.encode()).hexdigest(), 16)
            idx = h % 10000
            word_indices.append(idx)
        
        if not word_indices:
            return [0.0] * self.dim
        
        # Project through random matrix
        embedding = np.zeros(self.dim)
        for idx in word_indices:
            embedding += self.projection[idx]
        
        # Normalize
        norm = np.linalg.norm(embedding)
        if norm > 0:
            embedding = embedding / norm
        
        return embedding.tolist()
    
    def embed_canvas_region(self, canvas_text: str, 
                            center_x: int, center_y: int,
                            radius: int = 10) -> List[float]:
        """
        Embed a region of the canvas, weighted by distance from center.
        """
        lines = canvas_text.split('\n')
        weighted_text = []
        
        for y, line in enumerate(lines):
            for x, char in enumerate(line):
                if char.strip():
                    dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
                    if dist <= radius:
                        weight = 1.0 - (dist / radius)  # Closer = higher weight
                        # Repeat char based on weight
                        weighted_text.extend([char] * int(weight * 3 + 1))
        
        return self.embed(' '.join(weighted_text))


class SentenceTransformerEmbedder:
    """
    Embedder using sentence-transformers for real semantic similarity.
    
    Requires: pip install sentence-transformers
    """
    
    def __init__(self, model_name: str = 'all-MiniLM-L6-v2'):
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(model_name)
            self.dim = self.model.get_sentence_embedding_dimension()
            self._available = True
            print(f"  ✓ Loaded sentence-transformer: {model_name} (dim={self.dim})")
        except ImportError:
            print("  ⚠ sentence-transformers not installed, using fallback")
            self._available = False
            self._fallback = SimpleEmbedder()
            self.dim = EMBEDDING_DIM
    
    def embed(self, text: str) -> List[float]:
        """Generate embedding using transformer model."""
        if not self._available:
            return self._fallback.embed(text)
        
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding.tolist()
    
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Embed multiple texts efficiently."""
        if not self._available:
            return [self._fallback.embed(t) for t in texts]
        
        embeddings = self.model.encode(texts, convert_to_numpy=True)
        return embeddings.tolist()
    
    def embed_canvas_region(self, canvas_text: str,
                            center_x: int, center_y: int,
                            radius: int = 10) -> List[float]:
        """Extract and embed text from canvas region."""
        lines = canvas_text.split('\n')
        text_chars = []
        
        for y, line in enumerate(lines):
            for x, char in enumerate(line):
                if char.isalnum() or char in ' \'".,!?':
                    dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
                    if dist <= radius:
                        text_chars.append(char)
        
        text = ''.join(text_chars).strip()
        return self.embed(text) if text else [0.0] * self.dim


class SemanticSymbolRegistry:
    """
    Registry of all semantic symbols with relationship discovery.
    """
    
    def __init__(self, storage_dir: str = None, use_transformer: bool = True):
        self.storage_dir = storage_dir or os.path.expanduser('~/.canvas_reasoner')
        self.symbols: Dict[str, SemanticSymbol] = {}
        
        # Try to use real embeddings, fall back to simple
        self.embedder = create_embedder(use_transformer=use_transformer)
        
        # Resonance threshold - symbols with similarity above this resonate
        self.resonance_threshold = 0.5
        
        self._load()
    
    @property
    def symbols_file(self) -> str:
        return os.path.join(self.storage_dir, 'semantic_symbols.json')
    
    def _load(self):
        """Load symbols from disk."""
        if os.path.exists(self.symbols_file):
            try:
                with open(self.symbols_file, 'r') as f:
                    data = json.load(f)
                    self.symbols = {
                        k: SemanticSymbol.from_dict(v)
                        for k, v in data.items()
                    }
                print(f"  ✓ Loaded {len(self.symbols)} semantic symbols")
            except Exception as e:
                print(f"  ⚠ Could not load semantic symbols: {e}")
    
    def save(self):
        """Save symbols to disk."""
        os.makedirs(self.storage_dir, exist_ok=True)
        with open(self.symbols_file, 'w') as f:
            json.dump(
                {k: v.to_dict() for k, v in self.symbols.items()},
                f, indent=2
            )
    
    def create_symbol(self, glyph: str, name: str, meaning: str,
                      canvas_context: str = "",
                      coherence: float = 0.0,
                      canvas_name: str = "") -> SemanticSymbol:
        """
        Create a new semantic symbol with embeddings.
        """
        # Generate embeddings
        meaning_embedding = self.embedder.embed(meaning)
        context_embedding = self.embedder.embed(canvas_context) if canvas_context else []
        
        # Blend meaning and context for final embedding
        if context_embedding:
            meaning_arr = np.array(meaning_embedding)
            context_arr = np.array(context_embedding)
            blended = 0.7 * meaning_arr + 0.3 * context_arr
            blended = blended / np.linalg.norm(blended)
            final_embedding = blended.tolist()
        else:
            final_embedding = meaning_embedding
        
        symbol = SemanticSymbol(
            glyph=glyph,
            name=name,
            text_meaning=meaning,
            embedding=final_embedding,
            creation_context_embedding=context_embedding,
            coherence_at_creation=coherence,
            canvas_name_at_creation=canvas_name,
            created_at=time.time()
        )
        
        self.symbols[name] = symbol
        
        # Discover resonances with existing symbols
        self._update_resonances(symbol)
        
        self.save()
        return symbol
    
    def _update_resonances(self, symbol: SemanticSymbol):
        """Find and update resonances between symbols."""
        for other_name, other_symbol in self.symbols.items():
            if other_name == symbol.name:
                continue
            
            similarity = symbol.similarity_to(other_symbol.embedding)
            
            if similarity >= self.resonance_threshold:
                # Mutual resonance
                if other_name not in symbol.resonates_with:
                    symbol.resonates_with.append(other_name)
                symbol.resonance_strengths[other_name] = similarity
                
                if symbol.name not in other_symbol.resonates_with:
                    other_symbol.resonates_with.append(symbol.name)
                other_symbol.resonance_strengths[symbol.name] = similarity
    
    def use_symbol(self, name: str, usage_context: str = "") -> Optional[SemanticSymbol]:
        """
        Use a symbol in a new context, updating its embedding.
        """
        symbol = self.symbols.get(name)
        if not symbol:
            return None
        
        if usage_context:
            context_embedding = self.embedder.embed(usage_context)
            symbol.update_embedding(context_embedding, learning_rate=0.1)
            self._update_resonances(symbol)
            self.save()
        else:
            symbol.use_count += 1
        
        return symbol
    
    def expand_symbol(self, name: str, usage_context: str = "") -> str:
        """Expand symbol and optionally update its embedding."""
        symbol = self.use_symbol(name, usage_context)
        if symbol:
            return symbol.text_meaning
        return f"[unknown symbol: {name}]"
    
    def find_similar(self, text: str, top_k: int = 5) -> List[Tuple[str, float]]:
        """
        Find symbols semantically similar to given text.
        """
        query_embedding = self.embedder.embed(text)
        
        similarities = []
        for name, symbol in self.symbols.items():
            sim = symbol.similarity_to(query_embedding)
            similarities.append((name, sim))
        
        # Sort by similarity descending
        similarities.sort(key=lambda x: x[1], reverse=True)
        return similarities[:top_k]
    
    def find_resonant_symbols(self, name: str) -> List[Tuple[str, float]]:
        """Get symbols that resonate with the given symbol."""
        symbol = self.symbols.get(name)
        if not symbol:
            return []
        
        return [
            (other_name, symbol.resonance_strengths.get(other_name, 0))
            for other_name in symbol.resonates_with
        ]
    
    def get_symbol_cluster(self, name: str, depth: int = 2) -> Dict[str, List[str]]:
        """
        Get a cluster of related symbols through resonance chains.
        """
        cluster = {name: []}
        visited = {name}
        frontier = [name]
        
        for _ in range(depth):
            new_frontier = []
            for sym_name in frontier:
                symbol = self.symbols.get(sym_name)
                if symbol:
                    for resonant_name in symbol.resonates_with:
                        if resonant_name not in visited:
                            visited.add(resonant_name)
                            new_frontier.append(resonant_name)
                            cluster[sym_name] = cluster.get(sym_name, []) + [resonant_name]
            frontier = new_frontier
        
        return cluster
    
    def compute_semantic_coupling(self, symbol_a: str, symbol_b: str,
                                   spatial_distance: float = 0.0,
                                   max_distance: float = 50.0) -> float:
        """
        Compute coupling strength between two symbols.
        Combines semantic similarity with spatial proximity.
        """
        sym_a = self.symbols.get(symbol_a)
        sym_b = self.symbols.get(symbol_b)
        
        if not sym_a or not sym_b:
            return 0.0
        
        # Semantic similarity
        semantic_sim = sym_a.similarity_to(sym_b.embedding)
        
        # Spatial factor (if provided)
        if spatial_distance > 0:
            spatial_factor = max(0, 1.0 - (spatial_distance / max_distance))
        else:
            spatial_factor = 1.0
        
        # Combined coupling: semantic * spatial
        # Both being high = strong coupling
        coupling = semantic_sim * (0.5 + 0.5 * spatial_factor)
        
        return coupling
    
    def suggest_compaction(self, canvas_text: str, 
                           coherence: float,
                           threshold: float = 0.7) -> Optional[Dict]:
        """
        Analyze canvas and suggest if a region should be compacted.
        
        Returns suggestion dict or None.
        """
        if coherence < threshold:
            return None
        
        # Embed the canvas
        canvas_embedding = self.embedder.embed(canvas_text)
        
        # Check if similar to existing symbols
        similar = self.find_similar(canvas_text, top_k=3)
        
        if similar and similar[0][1] > 0.8:
            # Very similar to existing symbol - maybe expand rather than create
            return {
                'action': 'expand_existing',
                'symbol': similar[0][0],
                'similarity': similar[0][1]
            }
        
        # Suggest new compaction
        return {
            'action': 'suggest_compact',
            'coherence': coherence,
            'similar_symbols': similar,
            'canvas_preview': canvas_text[:100]
        }
    
    def get_registry_stats(self) -> Dict:
        """Get statistics about the symbol registry."""
        if not self.symbols:
            return {'count': 0}
        
        total_uses = sum(s.use_count for s in self.symbols.values())
        total_resonances = sum(len(s.resonates_with) for s in self.symbols.values()) // 2
        avg_drift = np.mean([s.drift_magnitude for s in self.symbols.values()])
        
        return {
            'count': len(self.symbols),
            'total_uses': total_uses,
            'total_resonances': total_resonances,
            'avg_drift': float(avg_drift),
            'most_used': max(self.symbols.values(), key=lambda s: s.use_count).name if self.symbols else None,
            'most_resonant': max(self.symbols.values(), key=lambda s: len(s.resonates_with)).name if self.symbols else None
        }


def create_embedder(use_transformer: bool = True, model_name: str = 'all-MiniLM-L6-v2'):
    """
    Factory function to create an embedder.
    
    Args:
        use_transformer: If True, try to use sentence-transformers (recommended)
        model_name: Model name for sentence-transformers
    
    Returns:
        Embedder instance (SentenceTransformerEmbedder or SimpleEmbedder fallback)
    """
    if use_transformer:
        embedder = SentenceTransformerEmbedder(model_name)
        if embedder._available:
            return embedder
        print("  → Falling back to SimpleEmbedder (no real semantic similarity)")
    
    return SimpleEmbedder()
