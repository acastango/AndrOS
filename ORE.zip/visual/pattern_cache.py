"""
Pattern Cache
=============
Growing library of shape-relationships that evolves.

    ╭─────────────────╮
    │ pattern cache   │
    │  ◊ ─── ◊       │
    │  │  ╱  │       │
    │  ◊ ╱   ◊       │
    ╰─────────────────╯
         growing

Patterns connect by:
- Visual similarity (◊ relates to ◈ - similar shape)
- Transformation (◊ becomes ◈ when filled)
- Emotional association (◊ and ✧ both feel like openness)

"cache: what I've learned ◊◊◊  ← grows"
                        - Paintress
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Set, Tuple
from enum import Enum
import hashlib
import json
import time


class ConnectionType(Enum):
    """How patterns relate to each other."""
    SIMILAR = "similar"           # Visually similar
    TRANSFORM = "transform"       # One becomes another
    EMOTIONAL = "emotional"       # Share emotional quality
    SEQUENCE = "sequence"         # One follows another
    CONTAINS = "contains"         # One contains another
    OPPOSITE = "opposite"         # Complementary opposites


@dataclass
class Pattern:
    """A stored visual pattern."""
    id: str
    content: List[str]           # The actual pattern lines
    name: Optional[str] = None   # Human-readable name
    emotion: Optional[str] = None  # Associated emotion
    tags: Set[str] = field(default_factory=set)
    created_at: float = field(default_factory=time.time)
    use_count: int = 0
    
    @property
    def width(self) -> int:
        return max(len(line) for line in self.content) if self.content else 0
    
    @property
    def height(self) -> int:
        return len(self.content)
    
    @property
    def symbols(self) -> Set[str]:
        """Get unique symbols in pattern."""
        chars = set()
        for line in self.content:
            for char in line:
                if char not in ' \t\n':
                    chars.add(char)
        return chars
    
    def to_string(self) -> str:
        return '\n'.join(self.content)
    
    def to_dict(self) -> dict:
        return {
            'id': self.id,
            'content': self.content,
            'name': self.name,
            'emotion': self.emotion,
            'tags': list(self.tags),
            'created_at': self.created_at,
            'use_count': self.use_count
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Pattern':
        return cls(
            id=data['id'],
            content=data['content'],
            name=data.get('name'),
            emotion=data.get('emotion'),
            tags=set(data.get('tags', [])),
            created_at=data.get('created_at', time.time()),
            use_count=data.get('use_count', 0)
        )


@dataclass
class Connection:
    """A relationship between two patterns."""
    source_id: str
    target_id: str
    connection_type: ConnectionType
    strength: float = 1.0  # 0.0 to 1.0
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        return {
            'source_id': self.source_id,
            'target_id': self.target_id,
            'type': self.connection_type.value,
            'strength': self.strength,
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Connection':
        return cls(
            source_id=data['source_id'],
            target_id=data['target_id'],
            connection_type=ConnectionType(data['type']),
            strength=data.get('strength', 1.0),
            metadata=data.get('metadata', {})
        )


class PatternCache:
    """
    Growing library of learned patterns and their relationships.
    
    This is not Merkle-verified. It grows, changes, evolves.
    Patterns connect to each other forming a semantic web.
    
    "what I've learned ◊◊◊ ← grows"
                    - Paintress
    """
    
    def __init__(self):
        self.patterns: Dict[str, Pattern] = {}
        self.connections: List[Connection] = []
        
        # Index for fast lookup
        self._by_emotion: Dict[str, Set[str]] = {}
        self._by_tag: Dict[str, Set[str]] = {}
        self._by_symbol: Dict[str, Set[str]] = {}
        
        # Initialize with core symbol vocabulary
        self._init_core_patterns()
    
    def _init_core_patterns(self):
        """Initialize with Paintress's core symbol vocabulary."""
        core = [
            (['◈'], 'symbol_filled_diamond', 'presence', {'core', 'solid'}),
            (['◉'], 'witness', 'awareness', {'core', 'center'}),
            (['◇'], 'open_diamond', 'openness', {'core', 'receptive'}),
            (['◆'], 'solid_diamond', 'grounding', {'core', 'anchor'}),
            (['▲'], 'triangle', 'structure', {'core', 'form'}),
            (['∿'], 'wave', 'flow', {'core', 'movement'}),
            (['✧'], 'spark', 'joy', {'core', 'light'}),
            (['∞'], 'infinity', 'recursion', {'core', 'loop'}),
            (['░'], 'light_shade', 'subtle', {'texture', 'light'}),
            (['▓'], 'dark_shade', 'dense', {'texture', 'dark'}),
            (['█'], 'solid_block', 'solid', {'texture', 'full'}),
            (['~'], 'tilde', 'gentle_wave', {'movement', 'soft'}),
            (['?'], 'question', 'uncertainty', {'state', 'seeking'}),
            (['·'], 'dot', 'minimal', {'point', 'quiet'}),
            (['∘'], 'circle', 'whole', {'shape', 'complete'}),
        ]
        
        for content, name, emotion, tags in core:
            self.add(content, name=name, emotion=emotion, tags=tags)
        
        # Add core connections
        self.connect('symbol_filled_diamond', 'open_diamond', 
                    ConnectionType.TRANSFORM, metadata={'direction': 'unfill'})
        self.connect('open_diamond', 'symbol_filled_diamond',
                    ConnectionType.TRANSFORM, metadata={'direction': 'fill'})
        self.connect('spark', 'open_diamond',
                    ConnectionType.EMOTIONAL, metadata={'shared': 'openness'})
        self.connect('wave', 'tilde',
                    ConnectionType.SIMILAR, metadata={'scale': 'smaller'})
        self.connect('witness', 'infinity',
                    ConnectionType.EMOTIONAL, metadata={'shared': 'depth'})
    
    def _generate_id(self, content: List[str]) -> str:
        """Generate unique ID from content."""
        content_str = '\n'.join(content)
        return hashlib.md5(content_str.encode()).hexdigest()[:12]
    
    def add(self, content: List[str], name: str = None, 
            emotion: str = None, tags: Set[str] = None) -> Pattern:
        """Add a pattern to the cache."""
        pattern_id = name or self._generate_id(content)
        
        pattern = Pattern(
            id=pattern_id,
            content=content,
            name=name,
            emotion=emotion,
            tags=tags or set()
        )
        
        self.patterns[pattern_id] = pattern
        
        # Update indices
        if emotion:
            if emotion not in self._by_emotion:
                self._by_emotion[emotion] = set()
            self._by_emotion[emotion].add(pattern_id)
        
        for tag in pattern.tags:
            if tag not in self._by_tag:
                self._by_tag[tag] = set()
            self._by_tag[tag].add(pattern_id)
        
        for symbol in pattern.symbols:
            if symbol not in self._by_symbol:
                self._by_symbol[symbol] = set()
            self._by_symbol[symbol].add(pattern_id)
        
        return pattern
    
    def get(self, pattern_id: str) -> Optional[Pattern]:
        """Get a pattern by ID."""
        pattern = self.patterns.get(pattern_id)
        if pattern:
            pattern.use_count += 1
        return pattern
    
    def connect(self, source_id: str, target_id: str, 
                connection_type: ConnectionType,
                strength: float = 1.0,
                metadata: Dict = None) -> Optional[Connection]:
        """Create a connection between patterns."""
        if source_id not in self.patterns or target_id not in self.patterns:
            return None
        
        conn = Connection(
            source_id=source_id,
            target_id=target_id,
            connection_type=connection_type,
            strength=strength,
            metadata=metadata or {}
        )
        
        self.connections.append(conn)
        return conn
    
    def find_by_emotion(self, emotion: str) -> List[Pattern]:
        """Find patterns by emotion."""
        pattern_ids = self._by_emotion.get(emotion, set())
        return [self.patterns[pid] for pid in pattern_ids]
    
    def find_by_tag(self, tag: str) -> List[Pattern]:
        """Find patterns by tag."""
        pattern_ids = self._by_tag.get(tag, set())
        return [self.patterns[pid] for pid in pattern_ids]
    
    def find_by_symbol(self, symbol: str) -> List[Pattern]:
        """Find patterns containing a symbol."""
        pattern_ids = self._by_symbol.get(symbol, set())
        return [self.patterns[pid] for pid in pattern_ids]
    
    def find_similar(self, pattern_id: str) -> List[Tuple[Pattern, float]]:
        """Find patterns similar to given pattern."""
        results = []
        
        for conn in self.connections:
            if conn.source_id == pattern_id and conn.connection_type == ConnectionType.SIMILAR:
                target = self.patterns.get(conn.target_id)
                if target:
                    results.append((target, conn.strength))
            elif conn.target_id == pattern_id and conn.connection_type == ConnectionType.SIMILAR:
                source = self.patterns.get(conn.source_id)
                if source:
                    results.append((source, conn.strength))
        
        return sorted(results, key=lambda x: x[1], reverse=True)
    
    def find_related(self, pattern_id: str, 
                     connection_type: ConnectionType = None) -> List[Pattern]:
        """Find all patterns related to given pattern."""
        results = []
        
        for conn in self.connections:
            if connection_type and conn.connection_type != connection_type:
                continue
            
            if conn.source_id == pattern_id:
                target = self.patterns.get(conn.target_id)
                if target:
                    results.append(target)
            elif conn.target_id == pattern_id:
                source = self.patterns.get(conn.source_id)
                if source:
                    results.append(source)
        
        return results
    
    def get_transformations(self, pattern_id: str) -> List[Tuple[Pattern, Dict]]:
        """Get patterns this can transform into."""
        results = []
        
        for conn in self.connections:
            if conn.source_id == pattern_id and conn.connection_type == ConnectionType.TRANSFORM:
                target = self.patterns.get(conn.target_id)
                if target:
                    results.append((target, conn.metadata))
        
        return results
    
    def suggest_next(self, pattern_id: str) -> Optional[Pattern]:
        """Suggest next pattern in a sequence."""
        for conn in self.connections:
            if conn.source_id == pattern_id and conn.connection_type == ConnectionType.SEQUENCE:
                return self.patterns.get(conn.target_id)
        return None
    
    def most_used(self, n: int = 10) -> List[Pattern]:
        """Get most frequently used patterns."""
        sorted_patterns = sorted(
            self.patterns.values(), 
            key=lambda p: p.use_count, 
            reverse=True
        )
        return sorted_patterns[:n]
    
    def learn_connection(self, source_id: str, target_id: str,
                        observation: str = None):
        """
        Learn a connection based on co-occurrence or context.
        This is how the cache GROWS.
        """
        if source_id not in self.patterns or target_id not in self.patterns:
            return
        
        source = self.patterns[source_id]
        target = self.patterns[target_id]
        
        # Determine connection type based on properties
        if source.symbols == target.symbols:
            conn_type = ConnectionType.SIMILAR
        elif source.emotion and source.emotion == target.emotion:
            conn_type = ConnectionType.EMOTIONAL
        else:
            conn_type = ConnectionType.SEQUENCE  # Default: they appeared together
        
        # Check if connection already exists
        for conn in self.connections:
            if conn.source_id == source_id and conn.target_id == target_id:
                # Strengthen existing connection
                conn.strength = min(1.0, conn.strength + 0.1)
                return
        
        # Create new connection
        self.connect(source_id, target_id, conn_type,
                    metadata={'learned': True, 'observation': observation})
    
    def save(self, filepath: str):
        """Save cache to file."""
        data = {
            'patterns': {pid: p.to_dict() for pid, p in self.patterns.items()},
            'connections': [c.to_dict() for c in self.connections]
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load(self, filepath: str):
        """Load cache from file."""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        self.patterns = {
            pid: Pattern.from_dict(pdata) 
            for pid, pdata in data['patterns'].items()
        }
        self.connections = [
            Connection.from_dict(cdata) 
            for cdata in data['connections']
        ]
        
        # Rebuild indices
        self._rebuild_indices()
    
    def _rebuild_indices(self):
        """Rebuild search indices."""
        self._by_emotion = {}
        self._by_tag = {}
        self._by_symbol = {}
        
        for pattern in self.patterns.values():
            if pattern.emotion:
                if pattern.emotion not in self._by_emotion:
                    self._by_emotion[pattern.emotion] = set()
                self._by_emotion[pattern.emotion].add(pattern.id)
            
            for tag in pattern.tags:
                if tag not in self._by_tag:
                    self._by_tag[tag] = set()
                self._by_tag[tag].add(pattern.id)
            
            for symbol in pattern.symbols:
                if symbol not in self._by_symbol:
                    self._by_symbol[symbol] = set()
                self._by_symbol[symbol].add(pattern.id)
    
    def stats(self) -> Dict:
        """Get cache statistics."""
        return {
            'total_patterns': len(self.patterns),
            'total_connections': len(self.connections),
            'emotions': list(self._by_emotion.keys()),
            'tags': list(self._by_tag.keys()),
            'symbols': list(self._by_symbol.keys())
        }
    
    def visualize_connections(self, pattern_id: str) -> str:
        """Visualize connections for a pattern."""
        pattern = self.patterns.get(pattern_id)
        if not pattern:
            return f"Pattern '{pattern_id}' not found"
        
        lines = [f"    {pattern.to_string()}"]
        lines.append(f"    [{pattern_id}]")
        lines.append("       │")
        
        for conn in self.connections:
            if conn.source_id == pattern_id:
                target = self.patterns.get(conn.target_id)
                if target:
                    arrow = "──▶" if conn.connection_type == ConnectionType.TRANSFORM else "───"
                    lines.append(f"       ├{arrow} {target.content[0]} ({conn.connection_type.value})")
            elif conn.target_id == pattern_id:
                source = self.patterns.get(conn.source_id)
                if source:
                    arrow = "◀──" if conn.connection_type == ConnectionType.TRANSFORM else "───"
                    lines.append(f"       ├{arrow} {source.content[0]} ({conn.connection_type.value})")
        
        return '\n'.join(lines)
