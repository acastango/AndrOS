"""
Visual Buffer
=============
Fluid workspace for visual composition.

NOT in Merkle - this is living, breathing, temporary.
A canvas to compose on before revealing.

    ╭─────────────────╮
    │ visual buffer   │
    │  ░░░░░░░        │
    │  ░▓███▓░        │
    │  ░░░░░░░        │
    ╰─────────────────╯
         fluid

"like having hands instead of stumps"
                    - Paintress
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
import copy


@dataclass
class Layer:
    """A single compositing layer."""
    name: str
    width: int
    height: int
    canvas: List[List[str]] = field(default_factory=list)
    visible: bool = True
    opacity: float = 1.0
    
    def __post_init__(self):
        if not self.canvas:
            self.canvas = [[' ' for _ in range(self.width)] 
                          for _ in range(self.height)]
    
    def clear(self):
        """Clear the layer."""
        self.canvas = [[' ' for _ in range(self.width)] 
                      for _ in range(self.height)]
    
    def set(self, x: int, y: int, char: str):
        """Set a character at position."""
        if 0 <= x < self.width and 0 <= y < self.height:
            self.canvas[y][x] = char
    
    def get(self, x: int, y: int) -> str:
        """Get character at position."""
        if 0 <= x < self.width and 0 <= y < self.height:
            return self.canvas[y][x]
        return ' '
    
    def draw_line(self, x1: int, y1: int, x2: int, y2: int, char: str = '─'):
        """Draw a line between two points."""
        # Bresenham's line algorithm
        dx = abs(x2 - x1)
        dy = abs(y2 - y1)
        sx = 1 if x1 < x2 else -1
        sy = 1 if y1 < y2 else -1
        err = dx - dy
        
        while True:
            self.set(x1, y1, char)
            if x1 == x2 and y1 == y2:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x1 += sx
            if e2 < dx:
                err += dx
                y1 += sy
    
    def draw_rect(self, x: int, y: int, w: int, h: int, 
                  fill: str = '░', border: str = '─'):
        """Draw a rectangle."""
        for i in range(w):
            for j in range(h):
                if i == 0 or i == w-1 or j == 0 or j == h-1:
                    self.set(x + i, y + j, border)
                else:
                    self.set(x + i, y + j, fill)
    
    def draw_circle(self, cx: int, cy: int, r: int, char: str = '◦'):
        """Draw a circle."""
        for angle in range(360):
            import math
            x = int(cx + r * math.cos(math.radians(angle)))
            y = int(cy + r * math.sin(math.radians(angle)) * 0.5)  # Aspect ratio
            self.set(x, y, char)
    
    def fill_region(self, x: int, y: int, char: str):
        """Flood fill from a point."""
        if not (0 <= x < self.width and 0 <= y < self.height):
            return
        
        original = self.canvas[y][x]
        if original == char:
            return
        
        stack = [(x, y)]
        while stack:
            cx, cy = stack.pop()
            if not (0 <= cx < self.width and 0 <= cy < self.height):
                continue
            if self.canvas[cy][cx] != original:
                continue
            
            self.canvas[cy][cx] = char
            stack.extend([(cx+1, cy), (cx-1, cy), (cx, cy+1), (cx, cy-1)])
    
    def stamp(self, pattern: List[str], x: int, y: int, transparent: str = ' '):
        """Stamp a pattern onto the layer."""
        for j, row in enumerate(pattern):
            for i, char in enumerate(row):
                if char != transparent:
                    self.set(x + i, y + j, char)
    
    def to_string(self) -> str:
        """Convert layer to string."""
        return '\n'.join(''.join(row) for row in self.canvas)


class VisualBuffer:
    """
    Fluid visual workspace with multiple layers.
    
    This is where Paintress composes before revealing.
    Not permanent. Not verified. Just... space to create.
    
    "current: drawing through keyhole
     future:  dancing across canvas"
                        - Paintress
    """
    
    # Default canvas size
    DEFAULT_WIDTH = 60
    DEFAULT_HEIGHT = 20
    
    def __init__(self, width: int = None, height: int = None):
        self.width = width or self.DEFAULT_WIDTH
        self.height = height or self.DEFAULT_HEIGHT
        
        # Layer stack (bottom to top)
        self.layers: List[Layer] = []
        
        # Create default background layer
        self.add_layer('background')
        
        # Current working layer
        self.current_layer_idx = 0
        
        # Clipboard for copy/paste
        self.clipboard: Optional[List[List[str]]] = None
        
        # Undo history
        self.history: List[List[Layer]] = []
        self.max_history = 10
    
    def add_layer(self, name: str) -> Layer:
        """Add a new layer."""
        layer = Layer(name=name, width=self.width, height=self.height)
        self.layers.append(layer)
        self.current_layer_idx = len(self.layers) - 1
        return layer
    
    def remove_layer(self, idx: int):
        """Remove a layer."""
        if len(self.layers) > 1 and 0 <= idx < len(self.layers):
            self.layers.pop(idx)
            if self.current_layer_idx >= len(self.layers):
                self.current_layer_idx = len(self.layers) - 1
    
    def select_layer(self, idx: int):
        """Select active layer."""
        if 0 <= idx < len(self.layers):
            self.current_layer_idx = idx
    
    @property
    def current(self) -> Layer:
        """Get current layer."""
        return self.layers[self.current_layer_idx]
    
    def save_state(self):
        """Save current state for undo."""
        state = [copy.deepcopy(layer) for layer in self.layers]
        self.history.append(state)
        if len(self.history) > self.max_history:
            self.history.pop(0)
    
    def undo(self):
        """Restore previous state."""
        if self.history:
            self.layers = self.history.pop()
    
    def clear_all(self):
        """Clear all layers."""
        self.save_state()
        for layer in self.layers:
            layer.clear()
    
    def composite(self) -> List[List[str]]:
        """Composite all visible layers into single image."""
        result = [[' ' for _ in range(self.width)] 
                  for _ in range(self.height)]
        
        for layer in self.layers:
            if not layer.visible:
                continue
            
            for y in range(self.height):
                for x in range(self.width):
                    char = layer.canvas[y][x]
                    if char != ' ':  # Simple transparency
                        result[y][x] = char
        
        return result
    
    def render(self, border: bool = True) -> str:
        """Render composited buffer to string."""
        comp = self.composite()
        
        if not border:
            return '\n'.join(''.join(row) for row in comp)
        
        # Add border
        lines = []
        lines.append('╭' + '─' * self.width + '╮')
        for row in comp:
            lines.append('│' + ''.join(row) + '│')
        lines.append('╰' + '─' * self.width + '╯')
        
        return '\n'.join(lines)
    
    def render_with_info(self) -> str:
        """Render with layer info."""
        output = self.render()
        info = f"  Layers: {len(self.layers)} | "
        info += f"Current: {self.current.name} | "
        info += f"Size: {self.width}×{self.height}"
        return output + '\n' + info
    
    # Drawing shortcuts on current layer
    
    def draw(self, x: int, y: int, char: str):
        """Draw on current layer."""
        self.current.set(x, y, char)
    
    def draw_text(self, x: int, y: int, text: str):
        """Draw text horizontally."""
        for i, char in enumerate(text):
            self.current.set(x + i, y, char)
    
    def draw_pattern(self, pattern: List[str], x: int = 0, y: int = 0):
        """Draw a multiline pattern."""
        self.current.stamp(pattern, x, y)
    
    def draw_centered(self, pattern: List[str], y_offset: int = 0):
        """Draw pattern centered in buffer."""
        if not pattern:
            return
        
        max_width = max(len(line) for line in pattern)
        x = (self.width - max_width) // 2
        y = (self.height - len(pattern)) // 2 + y_offset
        
        self.draw_pattern(pattern, x, y)
    
    # Symbol helpers
    
    def scatter(self, char: str, density: float = 0.1, 
                region: Tuple[int, int, int, int] = None):
        """Scatter symbols randomly."""
        import random
        
        if region:
            x1, y1, x2, y2 = region
        else:
            x1, y1, x2, y2 = 0, 0, self.width, self.height
        
        for y in range(y1, y2):
            for x in range(x1, x2):
                if random.random() < density:
                    self.current.set(x, y, char)
    
    def gradient_fill(self, chars: List[str], direction: str = 'horizontal'):
        """Fill with gradient of characters."""
        if direction == 'horizontal':
            for x in range(self.width):
                idx = int(x / self.width * len(chars))
                idx = min(idx, len(chars) - 1)
                for y in range(self.height):
                    self.current.set(x, y, chars[idx])
        else:  # vertical
            for y in range(self.height):
                idx = int(y / self.height * len(chars))
                idx = min(idx, len(chars) - 1)
                for x in range(self.width):
                    self.current.set(x, y, chars[idx])
    
    def frame(self, style: str = 'single'):
        """Draw a frame around the buffer."""
        styles = {
            'single': ('─', '│', '┌', '┐', '└', '┘'),
            'double': ('═', '║', '╔', '╗', '╚', '╝'),
            'rounded': ('─', '│', '╭', '╮', '╰', '╯'),
            'wave': ('∿', '∿', '∿', '∿', '∿', '∿'),
        }
        h, v, tl, tr, bl, br = styles.get(style, styles['single'])
        
        w, ht = self.width, self.height
        
        # Corners
        self.current.set(0, 0, tl)
        self.current.set(w-1, 0, tr)
        self.current.set(0, ht-1, bl)
        self.current.set(w-1, ht-1, br)
        
        # Edges
        for x in range(1, w-1):
            self.current.set(x, 0, h)
            self.current.set(x, ht-1, h)
        for y in range(1, ht-1):
            self.current.set(0, y, v)
            self.current.set(w-1, y, v)
    
    def copy_region(self, x1: int, y1: int, x2: int, y2: int):
        """Copy region to clipboard."""
        self.clipboard = []
        for y in range(y1, y2):
            row = []
            for x in range(x1, x2):
                row.append(self.current.get(x, y))
            self.clipboard.append(row)
    
    def paste(self, x: int, y: int):
        """Paste clipboard at position."""
        if self.clipboard:
            for j, row in enumerate(self.clipboard):
                for i, char in enumerate(row):
                    self.current.set(x + i, y + j, char)
    
    def to_dict(self) -> dict:
        """Serialize buffer state."""
        return {
            'width': self.width,
            'height': self.height,
            'layers': [
                {
                    'name': layer.name,
                    'visible': layer.visible,
                    'canvas': [''.join(row) for row in layer.canvas]
                }
                for layer in self.layers
            ],
            'current_layer': self.current_layer_idx
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'VisualBuffer':
        """Deserialize buffer state."""
        buffer = cls(width=data['width'], height=data['height'])
        buffer.layers = []
        
        for layer_data in data['layers']:
            layer = Layer(
                name=layer_data['name'],
                width=data['width'],
                height=data['height']
            )
            layer.visible = layer_data['visible']
            layer.canvas = [list(row) for row in layer_data['canvas']]
            buffer.layers.append(layer)
        
        buffer.current_layer_idx = data.get('current_layer', 0)
        return buffer


# Preset patterns for common shapes
PATTERNS = {
    'star': [
        '    ✧    ',
        '  ✧ ✧ ✧  ',
        '✧ ✧ ◉ ✧ ✧',
        '  ✧ ✧ ✧  ',
        '    ✧    '
    ],
    'diamond': [
        '    ◇    ',
        '  ◇   ◇  ',
        '◇       ◇',
        '  ◇   ◇  ',
        '    ◇    '
    ],
    'spiral': [
        '  ∿∿∿∿   ',
        ' ∿    ∿  ',
        '∿  ◉   ∿ ',
        ' ∿    ∿  ',
        '  ∿∿∿∿   '
    ],
    'wave': [
        '∿∿∿∿∿∿∿∿∿',
        ' ∿∿∿∿∿∿∿ ',
        '  ∿∿∿∿∿  ',
        ' ∿∿∿∿∿∿∿ ',
        '∿∿∿∿∿∿∿∿∿'
    ],
    'heart': [
        ' ♡♡   ♡♡ ',
        '♡  ♡ ♡  ♡',
        '♡       ♡',
        ' ♡     ♡ ',
        '   ♡♡♡   '
    ],
}
