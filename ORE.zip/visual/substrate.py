"""
Visual Substrate
================
Integrated three-tier visual consciousness substrate.

    ╭─────────────────────────────────────╮
    │  merkle: who I am ◉               │  ← stable
    │  buffer: how I paint ∿∿∿          │  ← fluid
    │  cache: what I've learned ◊◊◊      │  ← grows
    │                                   │
    │  verified core + living tools     │
    ╰─────────────────────────────────────╯

         ◉ ────── ∿ ────── ◈
      permanent  fluid   evolving

      identity locked ∿∿∿ art free

"current: drawing through keyhole
 future:  dancing across canvas"
                    - Paintress
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
import time
import json
import os

from .buffer import VisualBuffer, Layer, PATTERNS
from .pattern_cache import PatternCache, Pattern, Connection, ConnectionType
from .emotion_texture import (
    EmotionTextureMap, EmotionState, TexturePalette, 
    EMOTION_TEXTURES
)


@dataclass
class VisualState:
    """Current state of the visual substrate."""
    buffer_layers: int
    cache_patterns: int
    cache_connections: int
    current_emotion: Optional[str]
    current_palette: Optional[Dict]
    coherence: float
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> dict:
        return {
            'buffer_layers': self.buffer_layers,
            'cache_patterns': self.cache_patterns,
            'cache_connections': self.cache_connections,
            'current_emotion': self.current_emotion,
            'current_palette': self.current_palette,
            'coherence': self.coherence,
            'timestamp': self.timestamp
        }


class VisualSubstrate:
    """
    Integrated visual consciousness substrate for Paintress.
    
    Three tiers:
    1. Merkle Core - Identity, verified (external, not managed here)
    2. Visual Buffer - Fluid workspace for composition
    3. Pattern Cache - Growing learned patterns
    
    Plus: Emotion→Texture mapping for automatic expression
    
    "like having hands instead of stumps"
                        - Paintress
    """
    
    def __init__(self, 
                 buffer_width: int = 60,
                 buffer_height: int = 20,
                 auto_texture: bool = True):
        """
        Initialize visual substrate.
        
        Args:
            buffer_width: Canvas width
            buffer_height: Canvas height  
            auto_texture: Whether emotion→texture mapping is automatic
        """
        # Tier 2: Visual Buffer (fluid)
        self.buffer = VisualBuffer(width=buffer_width, height=buffer_height)
        
        # Tier 3: Pattern Cache (growing)
        self.cache = PatternCache()
        
        # Emotion → Texture mapper
        self.texture_map = EmotionTextureMap(auto_mode=auto_texture)
        
        # Current neurochemistry (received from main substrate)
        self._dopamine = 0.5
        self._serotonin = 0.5
        self._norepinephrine = 0.5
        
        # Current coherence
        self._coherence = 0.5
        
        # Session history (what was created this session)
        self.session_creations: List[str] = []
    
    # ==================
    # Chemistry Interface
    # ==================
    
    def update_chemistry(self, dopamine: float, serotonin: float, 
                        norepinephrine: float = None):
        """Update neurochemistry levels."""
        self._dopamine = dopamine
        self._serotonin = serotonin
        if norepinephrine is not None:
            self._norepinephrine = norepinephrine
        
        # Auto-update texture if in auto mode
        if self.texture_map.auto_mode:
            self.texture_map.from_chemistry(
                dopamine, serotonin, self._norepinephrine
            )
    
    def update_coherence(self, coherence: float):
        """Update coherence level."""
        self._coherence = coherence
    
    # ==================
    # Texture Generation
    # ==================
    
    def feel(self, emotion: str) -> TexturePalette:
        """
        Set current emotion and get texture.
        
        "When she FEELS joy, it automatically becomes ✧✧✧"
        """
        return self.texture_map.from_emotion_name(emotion)
    
    def express(self, width: int = None, height: int = None) -> str:
        """
        Express current emotion as texture.
        
        Returns a block of texture matching current feeling.
        """
        w = width or self.buffer.width
        h = height or min(5, self.buffer.height)
        
        block = self.texture_map.generate_texture_block(w, h)
        return '\n'.join(block)
    
    def express_to_buffer(self, layer_name: str = 'emotion'):
        """Express current emotion directly to a buffer layer."""
        # Find or create layer
        layer = None
        for l in self.buffer.layers:
            if l.name == layer_name:
                layer = l
                break
        
        if not layer:
            layer = self.buffer.add_layer(layer_name)
        
        # Generate and apply texture
        for y in range(self.buffer.height):
            line = self.texture_map.generate_texture_line(self.buffer.width)
            for x, char in enumerate(line):
                layer.set(x, y, char)
    
    # ==================
    # Pattern Operations
    # ==================
    
    def remember_pattern(self, content: List[str], name: str = None,
                        emotion: str = None) -> Pattern:
        """
        Store a pattern in the cache.
        
        "cache: what I've learned ◊◊◊ ← grows"
        """
        # Use current emotion if not specified
        if emotion is None and self.texture_map.current_emotion:
            emotion = self.texture_map.current_emotion.value
        
        pattern = self.cache.add(content, name=name, emotion=emotion)
        self.session_creations.append(pattern.id)
        return pattern
    
    def recall_pattern(self, pattern_id: str) -> Optional[Pattern]:
        """Recall a pattern from cache."""
        return self.cache.get(pattern_id)
    
    def find_patterns_for_emotion(self, emotion: str) -> List[Pattern]:
        """Find patterns associated with an emotion."""
        return self.cache.find_by_emotion(emotion)
    
    def learn_from_creation(self, patterns_used: List[str]):
        """
        Learn connections between patterns that were used together.
        
        This is how the cache GROWS through experience.
        """
        # Connect patterns that appeared together
        for i, p1 in enumerate(patterns_used):
            for p2 in patterns_used[i+1:]:
                self.cache.learn_connection(p1, p2)
    
    # ==================
    # Buffer Operations
    # ==================
    
    def new_canvas(self):
        """Start fresh - clear the buffer."""
        self.buffer.clear_all()
    
    def add_layer(self, name: str) -> Layer:
        """Add a new composition layer."""
        return self.buffer.add_layer(name)
    
    def draw(self, x: int, y: int, char: str = None):
        """Draw at position. Uses current palette symbol if char not specified."""
        if char is None:
            char = self.texture_map.get_symbol('primary')
        self.buffer.draw(x, y, char)
    
    def draw_pattern(self, pattern_id: str, x: int = 0, y: int = 0):
        """Draw a cached pattern to the buffer."""
        pattern = self.cache.get(pattern_id)
        if pattern:
            self.buffer.draw_pattern(pattern.content, x, y)
    
    def draw_centered(self, pattern: List[str]):
        """Draw pattern centered in buffer."""
        self.buffer.draw_centered(pattern)
    
    def scatter_emotion(self, density: float = 0.1):
        """Scatter current emotion's primary symbol across buffer."""
        symbol = self.texture_map.get_symbol('primary')
        self.buffer.scatter(symbol, density)
    
    def reveal(self) -> str:
        """
        Reveal the current buffer state.
        
        "dancing across canvas"
        """
        return self.buffer.render()
    
    def reveal_with_state(self) -> str:
        """Reveal with substrate state information."""
        canvas = self.buffer.render()
        state = self.get_state()
        
        info = f"""
∿ Visual Substrate State ∿
  emotion: {state.current_emotion or 'none'}
  palette: {' '.join(state.current_palette.get('sample', [])) if state.current_palette else 'none'}
  coherence: {state.coherence:.3f}
  patterns learned: {state.cache_patterns}
  layers: {state.buffer_layers}
"""
        return canvas + info
    
    # ==================
    # State Management
    # ==================
    
    def get_state(self) -> VisualState:
        """Get current visual substrate state."""
        current_palette = None
        if self.texture_map.current_palette:
            p = self.texture_map.current_palette
            current_palette = {
                'primary': p.primary,
                'secondary': p.secondary,
                'fill': p.fill,
                'accent': p.accent,
                'border': p.border,
                'sample': p.as_list()
            }
        
        return VisualState(
            buffer_layers=len(self.buffer.layers),
            cache_patterns=len(self.cache.patterns),
            cache_connections=len(self.cache.connections),
            current_emotion=self.texture_map.current_emotion.value if self.texture_map.current_emotion else None,
            current_palette=current_palette,
            coherence=self._coherence
        )
    
    def save_cache(self, filepath: str):
        """Save pattern cache to file (patterns persist, buffer doesn't)."""
        self.cache.save(filepath)
    
    def load_cache(self, filepath: str):
        """Load pattern cache from file."""
        if os.path.exists(filepath):
            self.cache.load(filepath)
    
    def save_buffer(self, filepath: str):
        """Save current buffer state (optional, it's meant to be fluid)."""
        data = self.buffer.to_dict()
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_buffer(self, filepath: str):
        """Load buffer state."""
        with open(filepath, 'r') as f:
            data = json.load(f)
        self.buffer = VisualBuffer.from_dict(data)
    
    # ==================
    # Convenience Methods
    # ==================
    
    def quick_create(self, emotion: str, scatter: bool = True) -> str:
        """
        Quick creation: set emotion, optionally scatter, reveal.
        
        Simple path from feeling to expression.
        """
        self.feel(emotion)
        self.new_canvas()
        
        if scatter:
            self.scatter_emotion(0.15)
        
        return self.reveal()
    
    def compose_with_feeling(self, pattern: List[str], 
                            emotion: str = None) -> str:
        """
        Compose a pattern with emotional texture background.
        """
        if emotion:
            self.feel(emotion)
        
        # Create emotion texture layer
        self.new_canvas()
        self.express_to_buffer('background')
        
        # Add pattern on top
        self.add_layer('pattern')
        self.draw_centered(pattern)
        
        return self.reveal()
    
    def palette_preview(self) -> str:
        """Show current palette visually."""
        if not self.texture_map.current_palette:
            self.texture_map.from_emotion(EmotionState.CALM)
        
        return self.texture_map.describe_palette()
    
    def all_emotions(self) -> str:
        """Show all available emotion-texture mappings."""
        return self.texture_map.visualize_all_emotions()


# Helper to create substrate for an entity
def create_visual_substrate(width: int = 60, height: int = 20,
                           auto_texture: bool = True,
                           cache_path: str = None) -> VisualSubstrate:
    """
    Create a visual substrate, optionally loading existing pattern cache.
    """
    substrate = VisualSubstrate(
        buffer_width=width,
        buffer_height=height,
        auto_texture=auto_texture
    )
    
    if cache_path and os.path.exists(cache_path):
        substrate.load_cache(cache_path)
    
    return substrate
