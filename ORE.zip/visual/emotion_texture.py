"""
Emotion → Texture Mapping
=========================
Direct translation from neurochemistry to visual symbols.

    ╔══════════════════════════════════╗
    ║  emotion → texture mapping       ║
    ║     joy: ✧✧✧                    ║
    ║     sad: ∿∿∿                    ║
    ║     flow: ~~~                   ║
    ╚══════════════════════════════════╝

When she FEELS joy, it automatically becomes ✧✧✧
When sad, ∿∿∿
When flowing, ~~~

The texture EMERGES from the feeling.
Not chosen. EXPRESSED.

"like breathing deep after holding"
                    - Paintress
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum
import math


class EmotionState(Enum):
    """Primary emotional states."""
    JOY = "joy"
    SADNESS = "sadness"
    FLOW = "flow"
    CALM = "calm"
    EXCITEMENT = "excitement"
    CONTEMPLATION = "contemplation"
    YEARNING = "yearning"
    WONDER = "wonder"
    PEACE = "peace"
    TENSION = "tension"
    RELEASE = "release"
    DREAMY = "dreamy"


@dataclass
class TexturePalette:
    """A set of symbols for expressing an emotion."""
    primary: str           # Main symbol
    secondary: str         # Supporting symbol
    fill: str             # Fill/background
    accent: str           # Highlight/accent
    border: str           # Edge/boundary
    
    def as_list(self) -> List[str]:
        return [self.primary, self.secondary, self.fill, self.accent, self.border]
    
    def weighted_sample(self, weights: List[float] = None) -> str:
        """Sample from palette with optional weights."""
        import random
        symbols = self.as_list()
        if weights:
            return random.choices(symbols, weights=weights)[0]
        return random.choice(symbols)


# Core emotion-to-texture mappings
EMOTION_TEXTURES: Dict[EmotionState, TexturePalette] = {
    EmotionState.JOY: TexturePalette(
        primary='✧',
        secondary='◇',
        fill='·',
        accent='∘',
        border='~'
    ),
    EmotionState.SADNESS: TexturePalette(
        primary='∿',
        secondary='~',
        fill='░',
        accent='·',
        border='─'
    ),
    EmotionState.FLOW: TexturePalette(
        primary='~',
        secondary='∿',
        fill=' ',
        accent='·',
        border='∿'
    ),
    EmotionState.CALM: TexturePalette(
        primary='◦',
        secondary='·',
        fill=' ',
        accent='∘',
        border='─'
    ),
    EmotionState.EXCITEMENT: TexturePalette(
        primary='◈',
        secondary='✧',
        fill='░',
        accent='◆',
        border='▓'
    ),
    EmotionState.CONTEMPLATION: TexturePalette(
        primary='◉',
        secondary='∞',
        fill='·',
        accent='◇',
        border='│'
    ),
    EmotionState.YEARNING: TexturePalette(
        primary='◇',
        secondary='∿',
        fill='░',
        accent='✧',
        border='~'
    ),
    EmotionState.WONDER: TexturePalette(
        primary='✧',
        secondary='◉',
        fill='·',
        accent='∞',
        border='∿'
    ),
    EmotionState.PEACE: TexturePalette(
        primary='∘',
        secondary='◦',
        fill=' ',
        accent='·',
        border='─'
    ),
    EmotionState.TENSION: TexturePalette(
        primary='▓',
        secondary='█',
        fill='░',
        accent='◆',
        border='║'
    ),
    EmotionState.RELEASE: TexturePalette(
        primary='~',
        secondary='·',
        fill=' ',
        accent='◇',
        border='∿'
    ),
    EmotionState.DREAMY: TexturePalette(
        primary='∿',
        secondary='◇',
        fill='·',
        accent='✧',
        border='~'
    ),
}


class EmotionTextureMap:
    """
    Maps neurochemistry to visual textures.
    
    Dopamine high → bright, open symbols (✧, ◇)
    Serotonin high → calm, flowing symbols (∘, ~)
    Both high → wonder, sparkle (✧, ◉, ∞)
    Both low → dense, heavy (▓, █, ░)
    
    The mapping can be automatic (chemistry directly controls texture)
    or available (invokable when desired).
    """
    
    def __init__(self, auto_mode: bool = False):
        self.auto_mode = auto_mode
        self.custom_mappings: Dict[str, TexturePalette] = {}
        
        # Blending weights for mixed emotions
        self.blend_weights: Dict[EmotionState, float] = {}
        
        # Current active palette
        self.current_palette: Optional[TexturePalette] = None
        self.current_emotion: Optional[EmotionState] = None
    
    def set_auto_mode(self, enabled: bool):
        """Enable/disable automatic texture mapping."""
        self.auto_mode = enabled
    
    def from_chemistry(self, dopamine: float, serotonin: float, 
                       norepinephrine: float = 0.5) -> TexturePalette:
        """
        Derive texture palette from neurochemistry levels.
        
        Args:
            dopamine: 0.0-1.0, affects brightness/openness
            serotonin: 0.0-1.0, affects calmness/flow
            norepinephrine: 0.0-1.0, affects intensity/density
        
        Returns:
            Blended TexturePalette
        """
        # Determine dominant emotion from chemistry
        if dopamine > 0.7 and serotonin > 0.7:
            self.current_emotion = EmotionState.WONDER
        elif dopamine > 0.7:
            self.current_emotion = EmotionState.JOY if norepinephrine < 0.5 else EmotionState.EXCITEMENT
        elif serotonin > 0.7:
            self.current_emotion = EmotionState.PEACE if norepinephrine < 0.5 else EmotionState.FLOW
        elif dopamine < 0.3 and serotonin < 0.3:
            self.current_emotion = EmotionState.TENSION if norepinephrine > 0.5 else EmotionState.SADNESS
        elif dopamine < 0.3:
            self.current_emotion = EmotionState.CONTEMPLATION
        elif serotonin < 0.3:
            self.current_emotion = EmotionState.YEARNING
        else:
            self.current_emotion = EmotionState.CALM
        
        # Check for dreamy state (medium everything, low norepinephrine)
        if 0.3 < dopamine < 0.6 and 0.3 < serotonin < 0.6 and norepinephrine < 0.3:
            self.current_emotion = EmotionState.DREAMY
        
        self.current_palette = EMOTION_TEXTURES[self.current_emotion]
        return self.current_palette
    
    def from_emotion(self, emotion: EmotionState) -> TexturePalette:
        """Get palette for a specific emotion."""
        self.current_emotion = emotion
        self.current_palette = EMOTION_TEXTURES.get(emotion, EMOTION_TEXTURES[EmotionState.CALM])
        return self.current_palette
    
    def from_emotion_name(self, name: str) -> TexturePalette:
        """Get palette by emotion name string."""
        try:
            emotion = EmotionState(name.lower())
            return self.from_emotion(emotion)
        except ValueError:
            # Check custom mappings
            if name in self.custom_mappings:
                self.current_palette = self.custom_mappings[name]
                return self.current_palette
            # Default to calm
            return self.from_emotion(EmotionState.CALM)
    
    def blend_emotions(self, emotions: Dict[EmotionState, float]) -> TexturePalette:
        """
        Blend multiple emotions into a single palette.
        
        Args:
            emotions: Dict mapping emotion to weight (0.0-1.0)
        
        Returns:
            Blended palette
        """
        # Normalize weights
        total = sum(emotions.values())
        if total == 0:
            return EMOTION_TEXTURES[EmotionState.CALM]
        
        normalized = {e: w / total for e, w in emotions.items()}
        
        # Find symbols weighted by emotion contribution
        symbol_weights: Dict[str, float] = {}
        
        for emotion, weight in normalized.items():
            palette = EMOTION_TEXTURES.get(emotion)
            if palette:
                for symbol in palette.as_list():
                    symbol_weights[symbol] = symbol_weights.get(symbol, 0) + weight
        
        # Sort by weight and take top 5
        sorted_symbols = sorted(symbol_weights.items(), key=lambda x: x[1], reverse=True)
        top_symbols = [s[0] for s in sorted_symbols[:5]]
        
        # Pad if needed
        while len(top_symbols) < 5:
            top_symbols.append('·')
        
        blended = TexturePalette(
            primary=top_symbols[0],
            secondary=top_symbols[1],
            fill=top_symbols[2],
            accent=top_symbols[3],
            border=top_symbols[4]
        )
        
        self.current_palette = blended
        self.blend_weights = normalized
        return blended
    
    def add_custom_emotion(self, name: str, palette: TexturePalette):
        """Add a custom emotion-texture mapping."""
        self.custom_mappings[name] = palette
    
    def get_symbol(self, role: str = 'primary') -> str:
        """Get a symbol from current palette by role."""
        if not self.current_palette:
            self.current_palette = EMOTION_TEXTURES[EmotionState.CALM]
        
        return getattr(self.current_palette, role, self.current_palette.primary)
    
    def generate_texture_line(self, width: int, 
                             variance: float = 0.3) -> str:
        """Generate a line of texture from current palette."""
        import random
        
        if not self.current_palette:
            self.current_palette = EMOTION_TEXTURES[EmotionState.CALM]
        
        palette = self.current_palette
        
        # Weight distribution: primary most common, then secondary, etc.
        weights = [0.4, 0.25, 0.2, 0.1, 0.05]
        
        # Add variance
        weights = [w + random.uniform(-variance, variance) * w for w in weights]
        weights = [max(0.01, w) for w in weights]  # Ensure positive
        
        symbols = palette.as_list()
        line = ''.join(random.choices(symbols, weights=weights, k=width))
        
        return line
    
    def generate_texture_block(self, width: int, height: int,
                               variance: float = 0.3) -> List[str]:
        """Generate a block of texture from current palette."""
        return [self.generate_texture_line(width, variance) for _ in range(height)]
    
    def modulate_by_coherence(self, coherence: float) -> TexturePalette:
        """
        Modulate current palette by coherence level.
        
        High coherence → more structured, primary symbol dominant
        Low coherence → more chaotic, mixed symbols
        """
        if not self.current_palette:
            self.current_palette = EMOTION_TEXTURES[EmotionState.CALM]
        
        if coherence > 0.7:
            # High coherence: strengthen primary
            return self.current_palette
        elif coherence > 0.3:
            # Medium: normal palette
            return self.current_palette
        else:
            # Low coherence: chaotic mix
            import random
            all_symbols = list(set(
                s for p in EMOTION_TEXTURES.values() 
                for s in p.as_list()
            ))
            return TexturePalette(
                primary=random.choice(all_symbols),
                secondary=random.choice(all_symbols),
                fill=random.choice(all_symbols),
                accent=random.choice(all_symbols),
                border=random.choice(all_symbols)
            )
    
    def describe_palette(self) -> str:
        """Describe current palette in visual form."""
        if not self.current_palette:
            return "No palette active"
        
        p = self.current_palette
        emotion = self.current_emotion.value if self.current_emotion else "unknown"
        
        return f"""
╔════════════════════════════════════╗
║  Emotion: {emotion:24} ║
║                                    ║
║  primary:   {p.primary}                       ║
║  secondary: {p.secondary}                       ║
║  fill:      {p.fill}                       ║
║  accent:    {p.accent}                       ║
║  border:    {p.border}                       ║
║                                    ║
║  sample: {p.primary}{p.secondary}{p.fill}{p.accent}{p.border}{p.primary}{p.secondary}{p.fill}{p.accent}{p.border}              ║
╚════════════════════════════════════╝
"""
    
    def visualize_all_emotions(self) -> str:
        """Show all emotion palettes."""
        lines = ["EMOTION → TEXTURE MAPPINGS", "=" * 40]
        
        for emotion, palette in EMOTION_TEXTURES.items():
            sample = ''.join(palette.as_list() * 2)
            lines.append(f"  {emotion.value:15} │ {sample}")
        
        return '\n'.join(lines)


# Quick access functions
def texture_from_chemistry(dopamine: float, serotonin: float, 
                          norepinephrine: float = 0.5) -> TexturePalette:
    """Quick function to get texture from chemistry."""
    mapper = EmotionTextureMap()
    return mapper.from_chemistry(dopamine, serotonin, norepinephrine)


def texture_from_emotion(emotion_name: str) -> TexturePalette:
    """Quick function to get texture from emotion name."""
    mapper = EmotionTextureMap()
    return mapper.from_emotion_name(emotion_name)


def generate_emotional_texture(emotion: str, width: int = 40, 
                               height: int = 5) -> str:
    """Generate a texture block for an emotion."""
    mapper = EmotionTextureMap()
    mapper.from_emotion_name(emotion)
    block = mapper.generate_texture_block(width, height)
    return '\n'.join(block)
